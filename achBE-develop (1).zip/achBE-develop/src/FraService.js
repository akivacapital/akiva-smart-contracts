const fs = require('fs');
const Tx = require('ethereumjs-tx').Transaction
const join = require('path').join;
const Web3 = require('web3')
const urljoin = require('url-join');
const { Logger } = require('./logger');

class FraService {
	constructor() {
    const web3 = new Web3(new Web3.providers.HttpProvider(urljoin(process.env.INFURA_API_URL, process.env.INFURA_API_KEY)));
    const web3WS = new Web3(new Web3.providers.WebsocketProvider(urljoin(process.env.INFURA_API_WS_URL, process.env.INFURA_API_KEY)));
    const owner = web3.eth.accounts.privateKeyToAccount(`0x${process.env.OWNER_PRIVATE_KEY}`);
    const contractPathBase = join(__dirname, '..', process.env.CONTRACTS_PATH)

    this.web3 = web3;
    this.web3WS = web3WS;
    this.contractPathBase = contractPathBase;
		this.contractFraMainAddress = process.env.FRA_FACTORY_ADDRESS; 
    this.contractFraMain = this.instantiateContract(join(contractPathBase, 'FraFactory.json'), process.env.FRA_FACTORY_ADDRESS);
    this.ownerAddr = owner.address;
	}
    
	instantiateContract(_abiPath, _address) {
    const parsed= JSON.parse(fs.readFileSync(_abiPath));
    return new this.web3WS.eth.Contract(parsed.abi, _address)
  }

  sendTransaction(data, gasLimit) {
    const txData = {
      gasLimit,
      gasPrice: this.web3.utils.toHex(1e9), // 1 Gwei
      to: this.contractFraMainAddress,
      from: this.ownerAddr,
      data: data
    };

    // get the number of transactions sent so far so we can create a fresh nonce
    return this.web3.eth.getTransactionCount(this.ownerAddr)
    .then(txCount => {
      const newNonce = this.web3.utils.toHex(txCount);
      const transaction = new Tx({ ...txData, nonce: newNonce }, { chain: 'kovan' }); // or 'rinkeby'
      transaction.sign(new Buffer.from(process.env.OWNER_PRIVATE_KEY, 'hex'));
      const serializedTx = '0x' + transaction.serialize().toString('hex');
      
      let TXHash = null;

      return new Promise((resolved, rejected) => {
        this.web3.eth.sendSignedTransaction(serializedTx)
          .on('transactionHash', hash => {
            TXHash = hash;
          })
          .on('receipt', receipt => {
            resolved(receipt)
          })
          .on('error', error => {
            rejected(TXHash)
          });
      })
    })
  }

	async runFunction(transactionName, params) {
    const batchAddress = [[]];

    const latestBlock = await this.web3.eth.getBlock('latest');
    const gasLimit = latestBlock.gasLimit;

    const agreementList = await this.contractFraMain.methods.getAgreementList().call();
    const ownerAddress = await this.contractFraMain.methods.owner().call();

    for(let i=0; i<agreementList.length; i++) {
      // check status
      const contractAgreement = this.instantiateContract(join(this.contractPathBase, 'Agreement.json'), agreementList[i]);
      if(!contractAgreement) continue;

      const isActiveAgreement = await contractAgreement.methods[params.status](3).call();

      if(!isActiveAgreement) continue;

      // estimate gas
      const arrayIndex = batchAddress.length - 1;
      
      try {
        batchAddress[arrayIndex].push(agreementList[i]);

        const batchGas = await this.contractFraMain.methods[params.fname](batchAddress[arrayIndex]).estimateGas({from: ownerAddress});

        if(batchGas >= gasLimit) {
          if(batchAddress[arrayIndex].length > 0) {
            batchAddress.push([batchAddress[arrayIndex].pop()]);
          }
        }
      }
      catch(error) {
        Logger.errorEstimation(transactionName, batchAddress[arrayIndex].pop());
      }
    }

    if(!batchAddress[batchAddress.length - 1].length) return;

    // send
    for(const addressArray of batchAddress) {
      try {
        const sendData = await this.contractFraMain.methods[params.fname](addressArray).encodeABI();
        const receipt = await this.sendTransaction(sendData, gasLimit);

        if(!params.logEvents) {
          continue;
        }

        const logs = [];

        for(let i=0; i<addressArray.length; i++) {
          const ins = this.instantiateContract(join(this.contractPathBase, 'Agreement.json'), addressArray[i]);
          const events = await ins.getPastEvents('allEvents', {fromBlock: receipt.blockNumber, toBlock: receipt.blockNumber });

          let filtered = events;

          if(params.topics) {
            filtered = filtered.filter(item => params.topics.indexOf(item.event) !== -1);
          }

          filtered = filtered.map(item => {
            const paramsKeys = Object.keys(item.returnValues);
            const params = paramsKeys
                            .filter(key => isNaN(+key))
                            .map(key => {
                              return {
                                key,
                                value: item.returnValues[key]
                              }
                            });

            return {
              event: item.event,
              params
            }
          });

          logs.push({
            address: addressArray[i],
            events: filtered
          });
        }

        if(logs.length > 0) {
          Logger.success(transactionName, receipt.transactionHash, logs);
        }
      }
      catch(TXHash) {
        Logger.errorSendTransaction(transactionName, TXHash, addressArray);
      }
    }
  }
}

module.exports = FraService;