const fs = require('fs');
const { join } = require('path');

const STATUS = {
  SUCCESS: 'success',
  ERROR: 'error'
};

const TYPE = {
  ESTIMATION :'estimation',
  SEND_TRANSACTION: 'sendTransaction'
};

class Logger {
  constructor () {
  }

  success (scope, hash, agreements) {
    this.write(scope, STATUS.SUCCESS, TYPE.SEND_TRANSACTION, hash, agreements);
  }

  errorSendTransaction (scope, hash, batchAddress) {
    const agreements = batchAddress.map(item => ({ address: item, events: [] }));

    this.write(scope, STATUS.ERROR, TYPE.SEND_TRANSACTION, hash, agreements);
  }

  errorEstimation (scope, address) {
    const agreements = [{
      address,
      events: []
    }];

    this.write(scope, STATUS.ERROR, TYPE.ESTIMATION, null, agreements);
  }
  
  write (scope, status, type, hash, agreements) {
    const data = {
      scope,
      status,
      type,
      hash,
      timestamp: new Date().getTime(),
      agreements: agreements || []
    }

    if(process.env.PRODUCTION !== 'true') {
      console.log(data);
    }

    const filename = join(__dirname, '..', 'logs', `${scope}.txt`);

    fs.appendFile(filename, `${JSON.stringify(data)}\n`, console.error);
  }
}

module.exports = {
  Logger: new Logger()
};