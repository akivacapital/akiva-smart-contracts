## Download

```shell
$ git clone https://gitlab.s-pro.io/akiva/cron
$ git checkout develop
```

# Installation
1. Create the environment file using .env.example:
```shell
$ cp .env.example .env
```
2. Make sure that environments you are using is correct. Check .env file for variables like owner private key (OWNER_PRIVATE_KEY), Infura configuration (INFURA_API_KEY, INFURA_API_URL, INFURA_API_WS_URL) and also FRA Factory address (FRA_FACTORY_ADDRESS).
3. Check CRON_TASK variable for setup correct cron job schedule. The variable represents a cron job that looks like this:
```shell
# ┌───────────── minute (0 - 59)
# │ ┌───────────── hour (0 - 23)
# │ │ ┌───────────── day of the month (1 - 31)
# │ │ │ ┌───────────── month (1 - 12)
# │ │ │ │ ┌───────────── day of the week (0 - 6) (Sunday to Saturday; 7 is also Sunday on some systems)
# │ │ │ │ │
# │ │ │ │ │
# * * * * *
```
4. Create and run the docker container (be sure that docker is running):
```shell
$ docker-compose up -d --build
```

## Using
Run docker container:
```shell
$ docker-compose up -d --build
```
Stop docker container:
```shell
$ docker-compose down
```

## How it works?
First of all Node.js run **index.js** file that create an bootstrapped cron job function. Each time as scheduled cron triggers the next tasks:
1. **AutoRejectAgreements** (function: batchRejectAgreements)
2. **UpdateAgreements** (function: batchUpdateAgreements; goes over these topics: AgreementUpdated, AssetsCollateralPush, AssetsCollateralPop, AssetsDaiPush, AssetsDaiPop, CdpOwnershipTransferred, AgreementClosed)