const cron = require('node-cron');
const FraService = require('./src/FraService');

require('dotenv').config();

const batchUpdateAgreementsTopics = [
	'AgreementUpdated',
	'AssetsCollateralPush',
	'AssetsCollateralPop',
	'AssetsDaiPush',
	'AssetsDaiPop',
	'CdpOwnershipTransferred',
	'AgreementClosed'
];

async function bootstrap() {
	const fra = new FraService();

	await fra.runFunction('AutoRejectAgreements', {
		fname: 'batchRejectAgreements',
		status: 'isBeforeStatus'
	});

	await fra.runFunction('UpdateAgreements', {
		fname: 'batchUpdateAgreements',
		status: 'isStatus',
		topics: batchUpdateAgreementsTopics,
		logEvents: true
	});
}

// bootstrap();

// run cron task
cron.schedule(process.env.CRON_TASK, bootstrap).start();