# Akiva Deploy Steps

Before running an application you should have domain name, ssl certificates and correct environment variables.



- Domain name should be changed *_front-dev.conf, front-dev-le-ssl.conf, env.dev_* files.

- SSL certificates should be located at *_/etc/letsencrypt/live/\<domain\>/ and changed in front-dev-le-ssl.conf._*

- Environment variables are located at env-dev file.



### 1. Clone projects repos to host. There are three repos in the project:

    - front

    - cron

    - ci

``` git clone -b develop [url of repo]_* ```  -b - is flag for branch, it could be changed related to yours one or could be removed if master branch is used. 



### 2. After the clone operation is done successfully, you&#39;ll find three folders in the current path - front, cron, ci

### 3. Go to ci folder. This folder contains different configuration files of deployment and one container for Apache with prebuilt SSL support.



Run the next:



```
docker import ci_web_1.tar ci_web_1
```



[will import image for Apache with SSL support]


```
 docker-compose -f docker-compose-dev.yml up -d --build
```


[will build images and start containers of the project&#39;s parts: cron and front. Front image contains the static content at _/var/www/front_, so will stop after starting automatically with Exit 0 code. It&#39;s normal.]


### 4. Run *_docker-compose -f docker-compose-dev.yml ps_* to ensure that ci_web_1 and akiva_cron_ containers are running.