export const environment = {
  production:          true,
  APP_NAME:            'akiva',
  HTTP_URL:            'https://alpha.akiva.capital/',
  // @TO-DO add mainnet apikey
  WALLETLINK_NET:      'https://mainnet.infura.io/v3/<YOUR_INFURA_API_KEY>',
  CHAIN_ID: 1,

  // 14th release
  FRA_FACTORY_ADDRESS: '0xbd96825245725b10792bb6ae1cc962fe740a7bec',
  FRA_QUERIES_ADDRESS: '0x018f1db68f2355c4501fe3f78aa40c0a3ed064dd',
  CONFIG_ADDRESS:      '0x4c775ea745b82d3cf92d153af0230f6e76fd212b',
  DAI_ADDRESS:         '0x1f9BEAf12D8db1e50eA8a5eD53FB970462386aA0',
};
