export const environment = {
  production:          true,
  APP_NAME:            'akiva',
  HTTP_URL:            'https://alpha.akiva.capital/',
  WALLETLINK_NET:      'https://kovan.infura.io/v3/789feaa01cfa4414863c8aacd51f8f2e',
  CHAIN_ID:             42,

  // 17th release
  FRA_FACTORY_ADDRESS: '0xb1b3fed6fa756c5a978a0e05f89b49e710ac9bcc',
  FRA_QUERIES_ADDRESS: '0xdd11aa72b55f25787c0b75883e24bd7a469d36e4',
  CONFIG_ADDRESS:      '0x8b4Ec4cfec2355Cf5A45573c992bb4D271CE45d6',
  DAI_ADDRESS:         '0x4f96fe3b7a6cf9725f59d353f723c1bdb64ca6aa',
};
