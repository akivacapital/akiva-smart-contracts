export const COLLATERAL_TYPES = [
  { value: 'ETH-A', isErc: false , symbol: 'ETH' },
  { value: 'BAT-A', isErc: true,   symbol: 'BAT' },
];

export const WIDGET_DATA = {
  generalData: [
    { title: 'Dai Savings Rate (DSR) %', value: '' },
    { title: 'Total Value Locked (USD)', value: '' },
    { title: 'Active Agreements',        value: '' },
    { title: 'Open Agreements',          value: '' },
    { title: 'Ended Agreements',         value: '' }
  ],
  collateralData: [
    { title: 'Price',         value: '', symbol: 'USD'},
    { title: 'Stability fee', value: '', symbol: '%'},
    { title: 'MCR',           value: '', symbol: '%'},
  ],
  stat: [
    { title: 'dai', value: '' },
    { title: 'eth', value: '' },
  ]
};

export const AGREEMENT_STATUSES = [
  { id: '0', status: 'all'     },
  { id: '1', status: 'pending' },
  { id: '2', status: 'open'    },
  { id: '3', status: 'active'  },
  { id: '4', status: 'closed'  },
];
