export * from './wallets/wallets.component';
