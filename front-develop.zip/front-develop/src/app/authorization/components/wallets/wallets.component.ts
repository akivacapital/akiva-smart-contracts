import { Component, OnInit, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';

import { PicturesConstants } from 'src/app/core/constants';
import { Web3Service } from 'src/app/core/services/web3.service';

import { takeWhile } from 'rxjs/operators';
import { MakerDaoService, SessionStorageService } from 'src/app/core/services';

@Component({
  selector: 'app-wallets',
  templateUrl: './wallets.component.html',
  styleUrls: ['./wallets.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class WalletsComponent implements OnInit, OnDestroy {

  public wallets: any;
  private _alive: boolean;

  constructor(
    private _router: Router,
    private _web3Service: Web3Service,
    private _makerDaoService: MakerDaoService,
    private _sessionStorageService: SessionStorageService
  ) {
    this.wallets = [
      { id: 1, name: 'Metamask',        icon: PicturesConstants.METAMASK, type: 'metamask'},
      { id: 2, name: 'Coinbase Wallet', icon: PicturesConstants.COINBASE, type: 'coinbase'}
    ];
    this._alive = true;
  }

  public ngOnInit() {
    this._sessionStorageService.remove('wallet');
  }

  public async chooseWallet(wallet: any) {

    this._web3Service.createProvider(wallet.type);

    await this._web3Service.enableProvider();

    this._web3Service.getWallets()
    .pipe(takeWhile(() => this._alive))
    .subscribe(wallets => {
      if (wallets && wallets[0]) {

        this._makerDaoService.createMDProvider();

        this._web3Service.web3Wallet = wallets[0];
        this._web3Service.updateWalletSubject(wallet.type);

        this._router.navigate(['/agreements/all']);
      }
    });
  }

  public ngOnDestroy() {
    this._alive = false;
  }
}
