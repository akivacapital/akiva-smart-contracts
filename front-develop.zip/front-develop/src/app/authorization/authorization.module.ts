import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthorizationRoutingModule } from './authorization-routing.module';
import { LogInComponent } from './containers/log-in/log-in.component';
import { SharedModule } from '../shared/shared.module';
import { WalletsComponent } from './components/wallets/wallets.component';

@NgModule({
  declarations: [
    LogInComponent,
    WalletsComponent
  ],
  imports: [
    AuthorizationRoutingModule,
    CommonModule,
    SharedModule,
  ]
})
export class AuthorizationModule { }
