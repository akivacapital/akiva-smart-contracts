import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatTooltipModule } from '@angular/material';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NgModule } from '@angular/core';

import { SidebarComponent, SimpleConfirmDialogComponent, SnackbarMessageComponent, SummaryWidgetComponent } from './components';
import { StopPropaginationDirective } from './directives';

@NgModule({
  declarations: [
    SidebarComponent,
    SimpleConfirmDialogComponent,
    SnackbarMessageComponent,
    StopPropaginationDirective,
    SummaryWidgetComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    ReactiveFormsModule,
  ],
  entryComponents: [SnackbarMessageComponent, SimpleConfirmDialogComponent],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    SidebarComponent,
    SimpleConfirmDialogComponent,
    SnackbarMessageComponent,
    StopPropaginationDirective,
    SummaryWidgetComponent,
  ]
})
export class SharedModule { }
