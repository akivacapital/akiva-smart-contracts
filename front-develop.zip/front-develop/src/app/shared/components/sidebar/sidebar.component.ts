import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

import { Web3Service } from 'src/app/core/services';

import { takeWhile } from 'rxjs/operators';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent implements OnInit, OnDestroy {

  public activeRoute: string;
  public menuItems:   any;
  public isAdmin: boolean;
  private _alive: boolean;

  constructor(
    private _router: Router,
    private _web3Service: Web3Service,
  ) {
    this._alive = true;
    this.isAdmin = this._web3Service.isAdmin;

    this.menuItems = [
      { title: 'Dashboard',  icon: 'home',       route:  '/agreements',       show: true },
      { title: 'Create New', icon: 'add',        route:  '/create-agreement', show: !this.isAdmin },
      { title: 'Users',      icon: 'people_alt', route:  '/users',            show: this.isAdmin },
    ];

    _router.events.subscribe(value => {
      if (value instanceof NavigationEnd) {
        this.activeRoute = value.url;
      }
    });
  }

  public ngOnInit() {

    this._web3Service.walletSubject$
      .pipe(takeWhile(() => this._alive))
      .subscribe(data => {
        this.isAdmin = data.isAdmin;
        this.menuItems[1].show = !data.isAdmin;
        this.menuItems[2].show = data.isAdmin;
      });
  }

  public isActiveRoute(route) {
    return this.activeRoute.includes(route);
  }

  public redirect(item?: any) {
    this._router.navigate([item ? item.route : '/authorization/log-in']);
  }

  public ngOnDestroy() {
    this._alive = false;
  }
}
