import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

import { COLLATERAL_TYPES, WIDGET_DATA } from '../../../../assets/mock/mockData';
import { MakerDaoService, SessionStorageService, Web3Service, ConvertDataService, CheckLoadedService } from 'src/app/core/services';

import { takeWhile, switchMap, combineAll } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-summary-widget',
  templateUrl: './summary-widget.component.html',
  styleUrls: ['./summary-widget.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SummaryWidgetComponent implements OnInit, OnDestroy {

  @Input()  public widgetType: string;
  @Input()  public actionBar: boolean;
  @Output() public closeEvent: EventEmitter<any> = new EventEmitter<any>();

  public widgetForm:         FormGroup;
  public colTypeFormControl: FormControl;

  public collateralTypes: any;
  public walletData:      any;
  public widgetData:      any;

  public isLoaded:   boolean;
  private _alive: boolean;

  constructor(
    private _cd:                    ChangeDetectorRef,
    private _checkLoadedService:    CheckLoadedService,
    private _convertDataService:    ConvertDataService,
    private _makerDaoService:       MakerDaoService,
    private _sessionStorageService: SessionStorageService,
    private _web3Service:           Web3Service,
  ) {
    this.collateralTypes = COLLATERAL_TYPES;
    this.widgetData      = WIDGET_DATA;
    this.walletData      = _sessionStorageService.get('wallet');

    this._alive = true;

    this._web3Service.walletSubject$
      .pipe(takeWhile(() => this._alive))
      .subscribe(data => {
        this.walletData = data;
        this.getWalletData();
      });
   }

  private _createFormControls(): void {
    this.colTypeFormControl = new FormControl('ETH-A');
  }

  private _createForm(): void {
    this.widgetForm = new FormGroup({
      collateralType: this.colTypeFormControl,
    });
  }

  public ngOnInit() {

    this._checkLoadedService.checkIsAllLoaded()
    .pipe(takeWhile(() => !this.isLoaded))
    .subscribe(alreadyLoaded => {
      if (alreadyLoaded && !this.isLoaded) {

        this.isLoaded = true;

        this._createFormControls();
        this._createForm();

        this.getWalletData();
        this.getWidgetGeneralData();
        this.collTypeChange(this.colTypeFormControl);
      }
    });
  }

  public dynamicClasses(type) {
    switch (type) {
      case 'color':
        return this.widgetType ? 'color-ebony' : 'color-white-liliac';
      case 'select':
        return this.widgetType ? 'white' : '';
      case 'panel':
        return this.widgetType ? '' : 'midnight-panel';
      default:
        break;
    }
  }

  public closeWidget() {
    this.closeEvent.next();
  }

  public getWalletData() {
    of(
      this._web3Service.getDaiBalance(),
      this._web3Service.getBalance(),
    )
    .pipe(
      combineAll(),
      takeWhile(() => this._alive)
    )
    .subscribe(wallet => {
      this.widgetData.stat[0].value = parseFloat(this._convertDataService.convertFromWei(wallet[0])).toFixed(7);
      this.widgetData.stat[1].value = parseFloat(this._convertDataService.convertFromWei(wallet[1])).toFixed(7);
      this._cd.detectChanges();
    });
  }

  public getWidgetGeneralData() {

    const getTotalValueLocked$ = this._web3Service.getActiveCdps()
                                     .pipe(
                                       switchMap(ids => this._makerDaoService.getCombinedColValue(ids)),
                                       combineAll()
                                     );

    of(
      this._makerDaoService.getDSR(),
      this._web3Service.getAgreementsCounts(),
      getTotalValueLocked$
    )
    .pipe(
      combineAll(),
      takeWhile(() => this._alive)
    )
    .subscribe(general => {

      let totalValueLocked = 0;

      if (general[2][0]._amount) {
        general[2].forEach((c: any) => totalValueLocked += c.toNumber());
      }

      this.widgetData.generalData[0].value = parseFloat(((general[0].toNumber() - 1) * 100).toFixed(2));
      this.widgetData.generalData[1].value = this._convertDataService.convertExp(totalValueLocked.toFixed(5));
      this.widgetData.generalData[2].value = general[1].cntActive;
      this.widgetData.generalData[3].value = general[1].cntOpen;
      this.widgetData.generalData[4].value = general[1].cntEnded;
      this._cd.detectChanges();
    });
  }

  public collTypeChange(event: any) {

    this._makerDaoService.cdpType = event.value;

    this._makerDaoService.getMDvalues()
     .pipe(takeWhile(() => this._alive))
     .subscribe(coll => {
      this.widgetData.collateralData[0].value = coll.price;
      this.widgetData.collateralData[1].value = coll.fee;
      this.widgetData.collateralData[2].value = coll.mcr;
      this._cd.detectChanges();
    });
  }

  public ngOnDestroy() {
    this._alive = false;
  }
}
