import { Component, Inject, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { MAT_SNACK_BAR_DATA } from '@angular/material';
import { SnackbarMessageData } from './snackbar-message.interface';

@Component({
  selector: 'app-snackbar-message',
  templateUrl: './snackbar-message.component.html',
  styleUrls: ['./snackbar-message.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SnackbarMessageComponent implements OnInit {

  public etherscanLink: string;

  constructor(
    @Inject(MAT_SNACK_BAR_DATA) public data: SnackbarMessageData
  ) { }

  public ngOnInit() {
    this.etherscanLink = `https://kovan.etherscan.io/tx/${this.data.hash}`;
  }
}
