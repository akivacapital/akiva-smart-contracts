export enum SnackbarMessageType {
    ERROR   = 'error',
    SUCCESS = 'success',
    WARNING = 'warning',
}
