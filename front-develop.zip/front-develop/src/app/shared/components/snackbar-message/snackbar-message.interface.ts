import { SnackbarMessageType } from './snackbar-message.enum';

export interface SnackbarMessageData {
    title: string;
    message: string;
    type: SnackbarMessageType;
    hash?: string;
}
