import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appStopPropagination]'
})
export class StopPropaginationDirective {

  @HostListener('mouseup', ['$event'])
  public onClick(event: any): void {
    event.stopPropagation();
  }

}
