import { Component, OnInit } from '@angular/core';

import { IProgressBar, ProgressBarService } from './core/services/progress-bar.service';
import { SessionStorageService, ContractsAbiService, MakerDaoService } from './core/services';
import { Web3Service } from './core/services/web3.service';

import { Subscription, of } from 'rxjs';
import { distinctUntilChanged, combineAll, finalize, takeWhile } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  public progressBarData: IProgressBar = {
    isShown: false,
    value: 0,
    mode: 'indeterminate',
    color: 'primary'
  };

  private _alive: boolean;
  private _progressBarSubscription: Subscription;

  constructor(
    private _contractAbiService: ContractsAbiService,
    private _makerDaoService: MakerDaoService,
    private _progressBarService: ProgressBarService,
    private _sessionStorageService: SessionStorageService,
    private _web3Service: Web3Service,
  ) {
    this._alive = true;
    this._progressBarSubscription = _progressBarService.progressBarAnnounced$
      .pipe(distinctUntilChanged())
      .subscribe(data => this.progressBarData = data);
  }

  public ngOnInit() {
    const sources: any = this._contractAbiService.initializeABI();
    const wallet = this._sessionStorageService.get('wallet');

    if (wallet && wallet.type) {
      this._web3Service.createProvider(wallet.type);
      this._makerDaoService.createMDProvider();
    }

    of(...sources)
      .pipe(
        combineAll(),
        finalize(() => {
          if (wallet.address) {
            this._web3Service.web3Wallet = wallet.address;
            this._web3Service.updateWalletSubject(wallet.type);
          }
          this._alive = true;
        }),
        takeWhile(() => this._alive)
      )
      .subscribe(result => this._contractAbiService.setABIs = result);

  }
}
