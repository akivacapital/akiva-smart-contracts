import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OnlyLoggedInGuard } from './core/guards/only-logged-in.guard';
import { RoleGuard } from './core/guards/role.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/authorization/log-in',
    pathMatch: 'full'
  },
  {
    path: 'authorization',
    loadChildren: () =>
      import('./authorization/authorization.module').then(
        m => m.AuthorizationModule
      ),
  },
  {
    path: 'agreements',
    loadChildren: () =>
      import('./agreements/agreements.module').then(
        m => m.AgreementsModule
      ),
    canActivate: [OnlyLoggedInGuard]
  },
  {
    path: 'create-agreement',
    loadChildren: () =>
      import('./create-agreement/create-agreement.module').then(
        m => m.CreateAgreementModule
      ),
    canActivate: [OnlyLoggedInGuard]
  },
  {
    path: 'users',
    loadChildren: () =>
      import('./users/users.module').then(
        m => m.UsersModule
      ),
    canActivate: [OnlyLoggedInGuard]
  },
  {
    path: '**',
    redirectTo: '/authorization/log-in'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
