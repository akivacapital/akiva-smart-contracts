import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule, MatCheckboxModule, MatSlideToggleModule, MatInputModule, MatRadioModule } from '@angular/material';
import { NgModule } from '@angular/core';

import { AgreementDetailsComponent, AgreementItemComponent, AgreementsHeaderComponent,
         AgreementsListComponent, AgreementsTableHeaderComponent } from './components';
import { AgreementsComponent, DetailsComponent } from './containers';
import { AgreementsRoutingModule } from './agreements-routing.module';
import { SharedModule } from '../shared/shared.module';
import { AgreementHistoryComponent } from './components/agreement-history/agreement-history.component';
import { AgreementsService } from './services/agreements.service';
import { DetailsDialogComponent } from './components/details-dialog/details-dialog.component';

@NgModule({
  declarations: [
    AgreementDetailsComponent,
    AgreementItemComponent,
    AgreementsComponent,
    AgreementsHeaderComponent,
    AgreementsListComponent,
    AgreementsTableHeaderComponent,
    DetailsComponent,
    AgreementHistoryComponent,
    DetailsDialogComponent,
  ],
  imports: [
    AgreementsRoutingModule,
    CommonModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    MatTabsModule,
    MatInputModule,
    MatTooltipModule,
    MatRadioModule,
    SharedModule,
  ],
  entryComponents: [ DetailsDialogComponent ],
  providers: [ AgreementsService ]
})
export class AgreementsModule { }
