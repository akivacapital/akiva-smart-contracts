import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AgreementsComponent, DetailsComponent } from './containers';

const routes: Routes = [
  {
    path: '',
    component: AgreementsComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'all'
      },
      { path: 'all',          component: AgreementsComponent },
      { path: 'active',       component: AgreementsComponent },
      { path: 'canceled',     component: AgreementsComponent },
      { path: 'ended',        component: AgreementsComponent },
      { path: 'liquidated',   component: AgreementsComponent },
      { path: 'open',         component: AgreementsComponent },
      { path: 'pending',      component: AgreementsComponent },
      { path: 'risky',        component: AgreementsComponent },
    ]
  },
  { path: 'details/:address', component: DetailsComponent }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgreementsRoutingModule { }
