export interface Details {
  borrower:         string;
  borrowerFraDebt:  string;
  cdpId:            string;
  collateralAmount: string;
  collateralType:   string;
  debtValue:        string;
  delta:            string;
  deltaCommon:      string;
  interestRate:     string;
  lastCheckTime:    string;
  lender:           string;
  role:             string;
  status:           string;
}
