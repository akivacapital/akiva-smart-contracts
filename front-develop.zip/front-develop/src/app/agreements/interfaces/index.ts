export * from './details.interface';
