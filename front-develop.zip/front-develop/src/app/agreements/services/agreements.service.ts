import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material';

import { Web3Service } from 'src/app/core/services/web3.service';
import { SnackbarMessageComponent } from 'src/app/shared/components/snackbar-message/snackbar-message.component';
import { Observable, from, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AgreementsService {

  private _wallet: string;

  private _histotyUpdateSubject = new Subject<any>();
  public histotyUpdateSubject$ = this._histotyUpdateSubject.asObservable();

  constructor(
    private _web3Service: Web3Service,
    private _snackBar: MatSnackBar
  ) { }

  public showError(hash: string) {
    this._snackBar.openFromComponent(SnackbarMessageComponent, { data: { message: 'Error!', type: 'error', hash }, duration: 7000 });
  }

  public createInstance(type: string, address?: string) {
    this._wallet = this._web3Service.web3Wallet;
    return this._web3Service.getInstance(type, address);
  }

  public getAgreementsList(): Observable<any> {
    return from(this.createInstance('factory').methods.getAgreementList().call());
  }

  public getSingleAgreement(address: string): Observable<any> {
    return from(this.createInstance('agreement', address).methods.getInfo().call());
  }

  public approveAgreement(data: any) {
    return from(this.createInstance('factory').methods
            .batchApproveAgreements(data.selectedAddresses)
            .send({ from: this._wallet })
            .on('error', (error, receipt) => {
              if (receipt) {
                this.showError(receipt.transactionHash);
              }
            }));
  }

  public matchAgreement(data: any) {
    return from(this.createInstance('agreement', data.agr.address).methods
            .matchAgreement()
            .send({ from: this._wallet })
            .on('error', (error, receipt) => {
              if (receipt) {
                this.showError(receipt.transactionHash);
              }
            }));
  }

  public rejectAgreement(data: any): Observable<any> {
    return from(this.createInstance('factory').methods
            .batchRejectAgreements(data.selectedAddresses)
            .send({ from: this._wallet })
            .on('error', (error, receipt) => {
              if (receipt) {
                this.showError(receipt.transactionHash);
              }
            }));
  }

  public cancelAgreement(data: any): Observable<any> {
    return from(this.createInstance('agreement', data.agr.address).methods
            .cancelAgreement()
            .send({ from: this._wallet })
            .on('error', (error, receipt) => {
              if (receipt) {
                this.showError(receipt.transactionHash);
              }
            }));
  }

  public spendTokensApprove(address: string, debt: string): Observable<any> {
    return from(this.createInstance('dai').methods
            .approve(address, debt)
            .send({ from: this._wallet }));
  }

  public getSeparateParams(address: string, requestArray: any, isDates: boolean): Observable<any> {

    const instance = this.createInstance('agreement', address);
    const streamsArray: any = [];

    if (isDates) {
      requestArray.forEach(r => streamsArray.push(instance.methods.statusSnapshots(r.param).call()));
    } else {
      requestArray.forEach(r => streamsArray.push(instance.methods[r]().call()));
    }

    return streamsArray;
  }

  public autoRejectAgreements() {
    return from(this.createInstance('factory').methods
      .autoRejectAgreements()
      .send({ from: this._wallet })
      .on('error', (error, receipt) => {
        if (receipt) {
          this.showError(receipt.transactionHash);
        }
      }));
  }

  public autoUpdateAgreements() {
    return from(this.createInstance('factory').methods
      .updateAgreements()
      .send({ from: this._wallet })
      .on('error', (error, receipt) => {
        if (receipt) {
          this.showError(receipt.transactionHash);
        }
      }));
  }

  public getHistoryEvents(address: string): Observable<any> {
    return from(this.createInstance('agreement', address)
      .getPastEvents('allEvents', { fromBlock: 0, toBlock: 'latest' }));
    }

  public checkAssets(address: string): Observable<any> {
    return from(this.createInstance('agreement', address).methods.getAssets(this._wallet).call());
  }

  public lockAditionalCollateral(address: string, amount: any, isErc: any): Observable<any> {
    if (isErc) {
      return from(this.createInstance('agreement', address)
        .methods.lockAdditionalCollateral(amount).send({ from: this._wallet }));
    } else {
      return from(this.createInstance('agreement', address)
        .methods.lockAdditionalCollateral(amount).send({ from: this._wallet, value: amount }));
    }
  }

  public withdrawAssets(address: string, amount: any, isDai: any): Observable<any> {
    const methodName = isDai ? 'withdrawDai' : 'withdrawCollateral';
    return from(this.createInstance('agreement', address)
    .methods[methodName](amount).send({from: this._wallet}));
  }

  public histotyUpdateSubject() {
    this._histotyUpdateSubject.next();
  }
}

