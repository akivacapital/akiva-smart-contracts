import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatSnackBar, MatDialog } from '@angular/material';
import { Router, NavigationEnd } from '@angular/router';
import { Title } from '@angular/platform-browser';

import { AgreementsService } from '../../services/agreements.service';
import { ConvertDataService, ProgressBarService, Web3Service, CheckLoadedService } from 'src/app/core/services';
import { SnackbarMessageComponent, SimpleConfirmDialogComponent } from 'src/app/shared/components';

import { of } from 'rxjs';
import { filter, takeWhile, finalize, combineAll } from 'rxjs/operators';

@Component({
  selector: 'app-agreements',
  templateUrl: './agreements.component.html',
  styleUrls: ['./agreements.component.scss']
})
export class AgreementsComponent implements OnInit, OnDestroy {

  public activeLinkIndex: number;
  public navLinks: any[];
  public tabStatus: string;

  public agreements:     any;
  public initAgreements: any;

  public isAdmin:         boolean;
  public isMyAgreements:  boolean;
  public isWidgetVisible: boolean;

  public isLoaded: boolean;

  private _alive: boolean;

  constructor(
    public dialog: MatDialog,
    private _agreementsService:  AgreementsService,
    private _checkLoadedService: CheckLoadedService,
    private _convertDataService: ConvertDataService,
    private _progressBarService: ProgressBarService,
    private _router:             Router,
    private _snackBar:           MatSnackBar,
    private _title:              Title,
    private _web3Service:        Web3Service,
  ) {
    this._title.setTitle('Dashboard');
    this._alive = true;

    this.activeLinkIndex = 0;
    this.isWidgetVisible = false;
    this.isAdmin = this._web3Service.isAdmin;

    this.navLinks = [
      { title: 'all',        path: `/agreements/all`       },
      { title: 'pending',    path: `/agreements/pending`   },
      { title: 'open',       path: `/agreements/open`      },
      { title: 'active',     path: `/agreements/active`    },
      { title: 'risky',      path: `/agreements/risky`     },
      { title: 'ended',      path: `/agreements/ended`     },
      { title: 'liquidated', path: `/agreements/liquidated`},
      { title: 'canceled',   path: `/agreements/canceled`  },
    ];

    this._router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        const paths = this.navLinks.map(link => link.path);
        const index = paths.indexOf(event.urlAfterRedirects);
        if (index !== -1) {
          this.activeLinkIndex = index;
          this.tabStatus = this.navLinks[index].title;
          if (this.isLoaded) {
            this.getAgreements();
          }
        }
      });
  }

  public ngOnInit() {

    this._web3Service.walletSubject$
      .pipe(takeWhile(() => this._alive))
      .subscribe(data => {
        this.isAdmin = data.isAdmin;
        if (this.isAdmin) {
          this.isMyAgreements = false;
        }
        this.getAgreements();
      });

    this._checkLoadedService.checkIsAllLoaded()
    .pipe(takeWhile(() => !this.isLoaded))
    .subscribe(isReady => {
      if (isReady && !this.isLoaded) {
        this.getAgreements();
      }
    });
  }

  public getAgreements(isUpdate?: boolean) {

    this.isLoaded = true;
    this._progressBarService.show();

    this._agreementsService.getAgreementsList()
    .pipe(takeWhile(() => this._alive))
    .subscribe(addresses => {

      const sources: any = [];

      addresses.forEach(address => {
        sources.push(this._agreementsService.getSingleAgreement(address));
      });

      of(...sources)
        .pipe(
          combineAll(),
          takeWhile(() => this._alive),
          finalize(() => setTimeout(() => this._progressBarService.hide(), 250))
        )
        .subscribe(agreements => {
          this.initAgreements = this._convertDataService.transmormAgreementsData(agreements);
          this.agreementsFilter();
        });
    });

    if (isUpdate) {
      this._snackBar.openFromComponent(SnackbarMessageComponent, { data: { message: 'Updated', type: 'success' }, duration: 1250 });
    }
  }

  public autoActionStart(event: any) {
    this.dialog
      .open(SimpleConfirmDialogComponent, {
        data: {
          title: 'Are you sure?',
          text: `You want to start auto cron ${event.title}`,
          apply: 'yes, please start',
          cancel: 'no'
        }
      })
      .afterClosed()
      .subscribe((answer: any) => {
        if (answer && answer.data) {
          this._progressBarService.show();
          this._agreementsService[`${event.funName}Agreements`]()
            .pipe(
              takeWhile(() => this._alive),
              finalize(() => this._progressBarService.hide())
            )
            .subscribe(() => {
              this._snackBar.openFromComponent(SnackbarMessageComponent, { data: { message: 'Success', type: 'success' }, duration: 1250 });
              this.getAgreements(true);
            });
        }
      });
  }

  public toogleWidget() {
    this.isWidgetVisible = !this.isWidgetVisible;
  }

  public showMyAgreements(onlyMy: boolean) {
    this.isMyAgreements = onlyMy;
    this.agreementsFilter();
  }

  public agreementsFilter() {
    switch (this.tabStatus) {
      case ('all'):
        this.agreements = this.initAgreements;
        break;
      case ('risky'):
        this.agreements = this.initAgreements.filter(a => a.isRisky);
        break;
      default:
        this.agreements = this.initAgreements.filter(a => a.status === this.tabStatus);
        break;
    }

    if (this.isMyAgreements) {
      this.agreements = this.agreements.filter(a => a.role !== 'customer');
    }
  }

  public ngOnDestroy() {
    this._alive = false;
  }
}
