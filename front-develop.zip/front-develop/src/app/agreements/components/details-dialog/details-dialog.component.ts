import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { takeWhile, finalize } from 'rxjs/operators';
import { AgreementsService } from '../../services';
import { ProgressBarService, ConvertDataService, MakerDaoService } from 'src/app/core/services';
import { COLLATERAL_TYPES } from 'src/assets/mock/mockData';

@Component({
  selector: 'app-details-dialog',
  templateUrl: './details-dialog.component.html',
  styleUrls: ['./details-dialog.component.scss']
})
export class DetailsDialogComponent implements OnInit, OnDestroy {

  public addCollateralForm: FormGroup;
  public amountFormControl: FormControl;
  public withdrawTypeFormControl: FormControl;

  public maxValue: number;
  public disabledSubmit: boolean;

  private _alive: boolean;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<DetailsDialogComponent>,
    private _agreementsService:  AgreementsService,
    private _convertDataService: ConvertDataService,
    private _makerDaoService:    MakerDaoService,
    private _progressBarService: ProgressBarService,
  ) {
    this.disabledSubmit = false;
    this._alive = true;
  }

  private _createFormControls(): void {
    this.amountFormControl = new FormControl();
    this.withdrawTypeFormControl = new FormControl('0');
  }

  private _createForm(): void {
    this.addCollateralForm = new FormGroup({
      amount:       this.amountFormControl,
      withdrawType: this.withdrawTypeFormControl,
    });
  }

  public ngOnInit(): void {
    this._createFormControls();
    this._createForm();
    if (this.data.isWithdraw) {
      this.withdrawTypeChange({value: 0});
    }
  }

  public withdrawTypeChange(event) {
    this.maxValue = +event.value ? this.data.details.daiVal : this.data.details.colVal;
    this.amountFormControl.setValidators([Validators.required, Validators.min(1e-18), Validators.max(this.maxValue)]);
    this.amountFormControl.setValue(this.maxValue);
    this.addCollateralForm.updateValueAndValidity();
  }

  public submit(): void {
    if (this.addCollateralForm.valid) {

      this._progressBarService.show();
      this.disabledSubmit = true;

      const methodName = this.data.isWithdraw ? 'withdrawAssets' : 'lockAditionalCollateral';
      const amount = this._convertDataService.convertToWei(this._convertDataService.convertExp(this.amountFormControl.value));
      this._makerDaoService.cdpType = this.data.details.collateralType;

      if (this.data.isWithdraw) {
        const withdrawType = +this.withdrawTypeFormControl.value;
        this.transactionRequest(methodName, amount, withdrawType);
      } else {
        const isErc = COLLATERAL_TYPES.find(t => t.value === this.data.details.collateralType).isErc;
        if (isErc) {
          this._makerDaoService.getERCtoken(this.amountFormControl.value, this.data.details.agreementAddress)
            .pipe(takeWhile(() => this._alive))
            .subscribe(
              res => this.transactionRequest(methodName, amount, isErc),
              err => {
                this._progressBarService.hide();
                this.disabledSubmit = false;
              });
        } else {
          this.transactionRequest(methodName, amount, isErc);
        }
      }

    } else {
      this.amountFormControl.markAsTouched();
    }
  }

  public transactionRequest(methodName: string, amount: string, thirdParam: any) {
    this._agreementsService
    [methodName](this.data.details.agreementAddress, amount, thirdParam)
      .pipe(
        takeWhile(() => this._alive),
        finalize(() => {
          this.disabledSubmit = false;
          this._progressBarService.hide();
        })
      )
      .subscribe(value => this.dialogRef.close(value));
  }

  public ngOnDestroy(): void {
    this._alive = false;
  }
}
