import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgreementsTableHeaderComponent } from './agreements-table-header.component';

describe('AgreementsTableHeaderComponent', () => {
  let component: AgreementsTableHeaderComponent;
  let fixture: ComponentFixture<AgreementsTableHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgreementsTableHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgreementsTableHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
