import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-agreements-table-header',
  templateUrl: './agreements-table-header.component.html',
  styleUrls: ['./agreements-table-header.component.scss'],
})
export class AgreementsTableHeaderComponent implements OnInit {

  @Input()  public isAdmin: boolean;
  @Input()  public agreements: any;
  @Output() public sortEventEmitter: EventEmitter<any> = new EventEmitter<any>();

  public tableHeader: any;
  public sortedCol: any;

  constructor() {

    this.tableHeader = [
      { title: 'Address',         fieldName: 'address'         , sort: true  },
      { title: 'Borrower',        fieldName: 'borrower'        , sort: true  },
      { title: 'Lender',          fieldName: 'lender'          , sort: true  },
      { title: 'Status',          fieldName: 'status'          , sort: true  },
      { title: 'Type',            fieldName: 'type'            , sort: true  },
      { title: 'Amount',          fieldName: 'collateralAmount', sort: true  },
      { title: 'DAI Debt (DAI)',  fieldName: 'debtValue'       , sort: true  },
      { title: 'Duration (days)', fieldName: 'duration'        , sort: true  },
      { title: 'Interest Rate %', fieldName: 'interestRate'    , sort: true  },
      { title: '',                fieldName: 'marker'          , sort: false },
      { title: 'Action',          fieldName: 'button-area'     , sort: false },
    ];
    this.sortedCol = this.tableHeader[0];
  }

  public ngOnInit() { }

  public isAllSelected(): boolean {
    const numRows = this.agreements.filter(agr => agr.status === 'pending');
    const numSelected = numRows.filter(row => row.isSelected);
    return numSelected.length === numRows.length;
  }

  public hasValue(): boolean {
    const numSelected = this.agreements ? this.agreements.filter(agr => agr.status === 'pending' && agr.isSelected) : [];
    return numSelected.length > 0;
  }

  public masterToggle() {
    const allSelected = this.isAllSelected();
    this.agreements = this.agreements.map(agr => {
      if (agr.status === 'pending') {
        agr.isSelected = !allSelected;
      }
      return agr;
    });
  }

  public orderBy(el) {
    if (this.sortedCol.title === el.title) {
      switch (this.sortedCol.type) {
        case 'desc':
          this.sortedCol.type = 'asc';
          break;
        case 'asc':
          this.sortedCol.type = '';
          break;
        default:
          this.sortedCol.type = 'desc';
          break;
      }
    } else {
      this.sortedCol = el;
      this.sortedCol.type = 'desc';
    }
    this.sortEventEmitter.next(this.sortedCol);
  }

}
