import { Component, OnInit, OnDestroy } from '@angular/core';
import { AgreementsService } from '../../services/agreements.service';
import { ActivatedRoute } from '@angular/router';
import { CheckLoadedService, Web3Service, ConvertDataService } from 'src/app/core/services';
import { COLLATERAL_TYPES } from 'src/assets/mock/mockData';

import { takeWhile, combineAll } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-agreement-history',
  templateUrl: './agreement-history.component.html',
  styleUrls: ['./agreement-history.component.scss']
})
export class AgreementHistoryComponent implements OnInit, OnDestroy {

  public agreementAddress: string;
  public isLoad:           boolean;
  public showList:         boolean;
  public agreementEvents:  any;

  public agreement:        any;
  private _alive: boolean;

  constructor(
    private _agreementsService: AgreementsService,
    private _checkLoadedService: CheckLoadedService,
    private _convertDataService: ConvertDataService,
    private _route: ActivatedRoute,
    private _web3Service: Web3Service,
  ) {
    this._alive = true;
    this.agreement = {};
    this.agreementEvents = [];
  }

  public ngOnInit() {

    this.agreement.agreementAddress = this._route.snapshot.params.address;

    this._agreementsService.histotyUpdateSubject$
      .pipe(takeWhile(() => this._alive))
      .subscribe(() => {
        if (this.isLoad) {
          this.getGeneralData();
          this.getHistoryEvents();
        }
      });

    this._checkLoadedService.checkIsAllLoaded()
      .pipe(takeWhile(() => !this.isLoad))
      .subscribe(isReady => {
        if (isReady) {
          this.getGeneralData();
          this.getHistoryEvents();
        }
      });
  }

  public getGeneralData() {

    this.isLoad = true;

    const generalParams = [
      'borrower',
      'collateralType',
      'lender',
    ];
    const params: any = this._agreementsService.getSeparateParams(this.agreement.agreementAddress, generalParams, false);

    of(...params)
    .pipe(
      combineAll(),
      takeWhile(() => this._alive),
    )
    .subscribe(values => {

      generalParams.forEach((p, i) => {
        this.agreement[p] = values[i];
      });

      this.agreement.collateralType = this._convertDataService.convertFromBytes32(this.agreement.collateralType);
      this.agreement.collSymbol = COLLATERAL_TYPES.find(t => t.value === this.agreement.collateralType).symbol;
    });
  }

  public getHistoryEvents() {
    this.agreementEvents = [];
    this._agreementsService.getHistoryEvents(this.agreement.agreementAddress)
    .pipe(takeWhile(() => this._alive))
    .subscribe(eventList => this.transformEvents(eventList));
  }

  public async transformEvents(eventList: any) {

    for (const event of eventList) {

      const values    = event.returnValues;
      const usersRole = values._holder === this.agreement.lender ? 'Lender' : 'Borrower';

      switch (event.event) {
        case 'AgreementInitiated':
          await this.addEvent(
            `Agreement is initiated. Collateral: ${this._convertDataService.convertFromWei(values._collateralValue) + ' ' + this.agreement.collSymbol}. \nDebt: ${this._convertDataService.convertFromWei(values._debtValue)} DAI. Interest rate: ${this._convertDataService.transformRecievedRate(values._interestRate)}%`, event);
          break;
        case 'AgreementApproved':
          await this.addEvent('Agreement is approved', event);
          break;
        case 'AgreementMatched':
            await this.addEvent(`Agreement is matched. ${this._convertDataService.convertFromWei(values._collateralAmount) + ' ' + this.agreement.collSymbol} is locked to vault. \n${this._convertDataService.convertFromWei(values._drawnDai)} DAI is drawn via vault. `, event);
            break;
        case 'AgreementUpdated':

          const currentDSR = this._convertDataService.transformRecievedRate(values._currentDsrAnnual);
          const savingDiff = this._convertDataService.convertFromWei(values._savingsDifference, true);

          await this.addEvent('Agreement is updated', event);
          await this.addEvent(`DSR (${ currentDSR }%) is in favour of ${ values._savingsDifference > 0 ? 'borrower' : 'lender' }.\nSavings difference is ${ savingDiff } DAI`);
          if (values._drawnDai > 0) {
            await this.addEvent(`${ this._convertDataService.convertFromWei(values._drawnDai) } DAI drawn via cdp`);
          }

          if (values._injectionAmount > 0) {
            await this.addEvent(`${ this._convertDataService.convertFromWei(values._injectionAmount) } DAI injected to cdp`);
          }

          if (values._delta > 0) {
            await this.addEvent(`Waiting for injection ${ this._convertDataService.convertFromWei(values._delta, true) } DAI`);
          } else if (values._delta < 0) {
            await this.addEvent(`Waiting for draw ${ this._convertDataService.convertFromWei('-' + values._delta, true) } DAI`);
          }
          break;
        case 'AgreementClosed':
          let message = 'Agreement is ';

          switch (+values._closedType) {
            case 0:
              message += 'terminated';
              break;
            case 1:
              message += 'liquidated';
              break;
            case 2:
              message += 'blocked';
              break;
            case 3:
              message += 'canceled';
              break;
          }
          await this.addEvent(message, event);
          break;
        case 'AssetsCollateralPush':
          await this.addEvent(`${usersRole} collateral assets increased by ${this._convertDataService.convertFromWei(values._amount) + ' ' + this.agreement.collSymbol}`);
          break;
        case 'AssetsCollateralPop':
          await this.addEvent(`${usersRole} withdraw ${this._convertDataService.convertFromWei(values._amount) + ' ' + this.agreement.collSymbol}`, event);
          break;
        case 'AssetsDaiPush':
          await this.addEvent(`${usersRole} DAI assets increased by ${ this._convertDataService.convertFromWei(values._amount)} DAI`);
          break;
        case 'AssetsDaiPop':
          await this.addEvent(`${usersRole} withdraw ${this._convertDataService.convertFromWei(values._amount)} DAI`, event);
          break;
        case 'AdditionalCollateralLocked':
          await this.addEvent(`Additional ${this._convertDataService.convertFromWei(values._amount) + ' ' + this.agreement.collSymbol} locked to agreement`, event);
          break;
        case 'CdpOwnershipTransferred':
          await this.addEvent(`The ownership of Vault ${values._cdpId} is transfered to borrower.`);
          break;
        case 'RiskyToggled':
          await this.addEvent(values._isRisky ? `The agreement is risky .` : `The agreement is not risky .`);
          break;
        default:
          break;
      }
    }

    this.showList = true;
  }

  public async addEvent(action: string, e?: any) {

    const event: any = {};

    if (e) {
      const eventBlock = await this._web3Service.web3Provider.eth.getBlock(e.blockNumber);

      event.name = e.event;
      event.hash = e.transactionHash;
      event.date = new Date(eventBlock.timestamp * 1000);
    }

    event.action = action;

    this.agreementEvents.push(event);
  }

  public goToEtherscan(hash: any) {
    window.open(`https://kovan.etherscan.io/tx/${hash}`, '_blank');
  }

  public ngOnDestroy() {
    this._alive = false;
  }
}
