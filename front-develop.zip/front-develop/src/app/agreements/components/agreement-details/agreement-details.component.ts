import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { MatDialog, MatSnackBar } from '@angular/material';

import { COLLATERAL_TYPES } from 'src/assets/mock/mockData';
import { AgreementsService } from '../../services/agreements.service';
import { MakerDaoService, ConvertDataService, CheckLoadedService, ProgressBarService, Web3Service } from 'src/app/core/services';

import { SnackbarMessageComponent } from 'src/app/shared/components';
import { DetailsDialogComponent } from '../details-dialog/details-dialog.component';

import { of } from 'rxjs';
import { combineAll, takeWhile, finalize } from 'rxjs/operators';

@Component({
  selector: 'app-agreement-details',
  templateUrl: './agreement-details.component.html',
  styleUrls: ['./agreement-details.component.scss'],
})
export class AgreementDetailsComponent implements OnInit, OnDestroy {

  public details: any;

  public isLoad:      boolean;
  public isExpired:   boolean;
  public showAddInfo: boolean;

  public _alive: boolean;

  constructor(
    public dialog:               MatDialog,
    private _agreementsService:  AgreementsService,
    private _checkLoadedService: CheckLoadedService,
    private _convertDataService: ConvertDataService,
    private _makerDaoService:    MakerDaoService,
    private _progressBarService: ProgressBarService,
    private _route:              ActivatedRoute,
    private _snackBar:           MatSnackBar,
    private _title:              Title,
    private _web3Service:        Web3Service,
  ) {
    this._title.setTitle('Details');
    this.details = [];
    this._alive = true;
  }

  public ngOnInit() {

    this.details.agreementAddress = this._route.snapshot.params.address;

    this._web3Service.walletSubject$
      .pipe(takeWhile(() => this._alive))
      .subscribe(() => {
        if (this.isLoad) {
          this.getAssetsInfo();
          this.getGeneralInfo();
        }
      });

    this._checkLoadedService.checkIsAllLoaded()
    .pipe(takeWhile(() => !this.isLoad))
    .subscribe(isReady => {
      if (isReady) {
        this.getAssetsInfo();
        this.getGeneralInfo();
      }
    });
  }

  public getAssetsInfo() {
    this.isLoad = true;
    this._agreementsService.checkAssets(this.details.agreementAddress)
      .pipe(takeWhile(() => this._alive))
      .subscribe(val => {
        this.details.colVal  = this._convertDataService.convertFromWei(val[0]);
        this.details.daiVal  = this._convertDataService.convertFromWei(val[1]);
      });
  }

  public getGeneralInfo() {

    this._progressBarService.show();

    const generalParams = [
      'borrower',
      'cdpId',
      'closedType',
      'collateralAmount',
      'collateralType',
      'debtValue',
      'expireDate',
      'interestRate',
      'isRisky',
      'lender',
      'status',
    ];

    const dateParams = [
      { name: 'initialDate', param: 1},
      { name: 'approveDate', param: 2},
      { name: 'matchDate',   param: 3},
      { name: 'closeDate',   param: 4}
    ];

    const generalSource: any = this._agreementsService.getSeparateParams(this.details.agreementAddress, generalParams, false);
    const datesSource:   any = this._agreementsService.getSeparateParams(this.details.agreementAddress, dateParams, true);

    of(...generalSource, ...datesSource)
      .pipe(
        combineAll(),
        takeWhile(() => this._alive),
        finalize(() => setTimeout(() => this._progressBarService.hide(), 300))
      )
      .subscribe(val => {

        const dates = val.slice(-4);

        generalParams.forEach((p, i) => {
          this.details[p] = val[i];
        });

        dateParams.forEach((d, i) => {
          this.details[d.name] = dates[i];
        });

        this.details.status = this._convertDataService.checkStatus(this.details.status, +this.details.closedType);
        this.details.collateralType = this._convertDataService.convertFromBytes32(this.details.collateralType);

        this.resetCdp(this.details.status, this.details.collateralType);

        this.details.collSymbol     = COLLATERAL_TYPES.find(t => t.value === this.details.collateralType).symbol;
        this.details.initDebtValue  = this._convertDataService.convertFromWei(this.details.debtValue);
        this.details.initCollAmount = this._convertDataService.convertFromWei(this.details.collateralAmount);

        this.details.expireDate     = +this.details.expireDate  ? new Date(this.details.expireDate  * 1000) : '';
        this.details.initialDate    = +this.details.initialDate ? new Date(this.details.initialDate * 1000) : '';
        this.details.approveDate    = +this.details.approveDate ? new Date(this.details.approveDate * 1000) : '';
        this.details.matchDate      = +this.details.matchDate   ? new Date(this.details.matchDate   * 1000) : '';
        this.details.closeDate      = +this.details.closeDate   ? new Date(this.details.closeDate   * 1000) : '';
        this.details.interestRate   = this._convertDataService.transformRecievedRate(this.details.interestRate);
        this.details.role           = this._convertDataService.checkAgreementRole(this.details.borrower, this.details.lender);

        if (this.details.isRisky && this.details.role === 'borrower') {
          this._snackBar.openFromComponent(SnackbarMessageComponent, {
            data: {
              message: `Attention! This agreement has reached risky status. It can be liquidated soon.
                        If you want to avoid liquidation - plese lock additional collateral to this agreement.`,
              type: 'warning' }, duration: 10000 });
        }
      });
  }

  public getAdditionalInfo() {

    const addInfoParams = [
      'borrowerFraDebt',
      'delta',
      'drawnTotal',
      'injectedTotal'
    ];

    const additional: any = this._agreementsService.getSeparateParams(this.details.agreementAddress, addInfoParams, false);

    of(...additional, this._makerDaoService.getDetailsAdditionalInfo(+this.details.cdpId))
      .pipe(
        combineAll(),
        takeWhile(() => this._alive)
      )
      .subscribe(val => {
        const info: any = val[val.length - 1];

        addInfoParams.forEach((p, i) => {
          this.details[p] = val[i];
        });

        this.details.pendingInjection = this.details.delta > 0 ? this._convertDataService.convertFromWei(this.details.delta, true) : 0;

        this.details.collRate         = info.debtValue > 0 ? info.collRatio : 0;
        this.details.collateralAmount = this._convertDataService.convertExp(info.collAmount);
        this.details.collateralValue  = this._convertDataService.convertExp(info.collValue);
        this.details.outstandingDebt  = this._convertDataService.convertExp(info.debtValue);
        this.details.borrowerFraDebt  = this._convertDataService.convertFromWei(this.details.borrowerFraDebt);

        this.details.drawnTotal     = this._convertDataService.convertFromWei(this.details.drawnTotal);
        this.details.injectedTotal  = this._convertDataService.convertFromWei(this.details.injectedTotal);

        this.showAddInfo = true;
      });
  }

  public openDialog(isWithdraw: boolean) {
    const height = isWithdraw ? '280px' : '250px';

    const data = {
      isWithdraw,
      details: this.details
    };

    this.dialog
      .open(DetailsDialogComponent, {
        width: '500px',
        height,
        data
      })
      .afterClosed()
      .subscribe(result => {
        if (result) {
          this._snackBar.openFromComponent(SnackbarMessageComponent, { data: { message: 'Success', type: 'success' }, duration: 1500 });
          this.resetCdp(this.details.status, this.details.collateralType);
          this.getAssetsInfo();
          this.getGeneralInfo();
          this._agreementsService.histotyUpdateSubject();
        }
      });
  }

  public resetCdp(status: string, collType: string) {
    if (!['pending', 'open', 'canceled'].includes(status)) {
      this._makerDaoService.cdpType = collType;

      this._makerDaoService.resetCdp()
        .pipe(
          takeWhile(() => this._alive),
          finalize(() => this.getAdditionalInfo()))
        .subscribe();
    }
  }

  public disabledBtn(bntType: string) {
    if (bntType === 'withdraw') {
      return this.details.role === 'customer' || (!+this.details.colVal && !+this.details.daiVal);
    } else {
      return this.details.role !== 'borrower';
    }
  }

  public ngOnDestroy() {
    this._snackBar.dismiss();
    this._alive = false;
  }
}

