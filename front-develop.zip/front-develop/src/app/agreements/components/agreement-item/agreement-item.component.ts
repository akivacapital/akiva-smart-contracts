import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';

import { SnackbarMessageComponent, SimpleConfirmDialogComponent } from 'src/app/shared/components';

@Component({
  selector: 'app-agreement-item',
  templateUrl: './agreement-item.component.html',
  styleUrls: ['./agreement-item.component.scss'],
})
export class AgreementItemComponent implements OnInit {

  @Input()  public agr: any;
  @Input()  public isAdmin: boolean;
  @Output() public actionsEventEmitter: EventEmitter<any> = new EventEmitter<any>();

  public mouseDownTime: Date;
  public mouseUpTime:   Date;

  constructor(
    public dialog: MatDialog,
    private _router: Router,
    private _snackBar: MatSnackBar,
  ) { }

  public ngOnInit() {
  }

  public copyToClipboard(item) {
    document.addEventListener('copy', (e: ClipboardEvent) => {
      e.clipboardData.setData('text/plain', (item));
      e.preventDefault();
      document.removeEventListener('copy', null);
    });
    document.execCommand('copy');
    this._snackBar.openFromComponent(SnackbarMessageComponent, { data: { message: 'Copied to clipboard', type: 'success' }, duration: 1250 });
  }

  public selectEvent(agr: any): void {
    agr.isSelected = !agr.isSelected;
  }

  public onMouseDown() {
    this.mouseDownTime = new Date();
  }

  public onMouseUp() {
    this.mouseUpTime = new Date();
    const secDiff = this.mouseUpTime.getSeconds() - this.mouseDownTime.getSeconds();
    const millDiff = ((this.mouseUpTime.getMilliseconds() - this.mouseDownTime.getMilliseconds()) < 200);
    if (!secDiff && millDiff) {
      this._router.navigate([`/agreements/details/${this.agr.address}`]);
    }
  }

  public actionButton(action: string) {

    const dialogData = {
      apply:  `yes, please ${action}`,
      cancel: 'no',
      text:   `You want to ${action} this transaction`,
      title:  'Are you sure?'
    };

    this.dialog
      .open(SimpleConfirmDialogComponent, {
        data: dialogData
      })
      .afterClosed()
      .subscribe((answer: any) => {
        if (answer && answer.data) {
          this.actionsEventEmitter.next({ action, agr: this.agr });
        }
      });
  }

}
