import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgreementItemComponent } from './agreement-item.component';

describe('AgreementItemComponent', () => {
  let component: AgreementItemComponent;
  let fixture: ComponentFixture<AgreementItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgreementItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgreementItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
