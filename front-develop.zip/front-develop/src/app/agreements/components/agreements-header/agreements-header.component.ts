import { Component, ChangeDetectionStrategy, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-agreements-header',
  templateUrl: './agreements-header.component.html',
  styleUrls: ['./agreements-header.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush
})
export class AgreementsHeaderComponent {

  @Input()  public isAdmin:        boolean;
  @Output() public onlyMyEvent: EventEmitter<any> = new EventEmitter<any>();
  @Output() public updateEvent: EventEmitter<any> = new EventEmitter<any>();
  @Output() public actionEvent: EventEmitter<any> = new EventEmitter<any>();

  constructor( ) { }

  public onlyMy(event) {
    this.onlyMyEvent.next(event.checked);
  }

  public updateList() {
    this.updateEvent.next();
  }

  public cronUpdateStart() {
    this.actionEvent.next({ title: 'update', funName: 'autoUpdate'});
  }

  public cronCloseStart() {
    this.actionEvent.next({ title: 'close', funName: 'autoReject' });
  }
}
