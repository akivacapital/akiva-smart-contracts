import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgreementsHeaderComponent } from './agreements-header.component';

describe('AgreementsHeaderComponent', () => {
  let component: AgreementsHeaderComponent;
  let fixture: ComponentFixture<AgreementsHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgreementsHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgreementsHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
