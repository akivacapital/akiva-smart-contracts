import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { MatSnackBar, MatDialog } from '@angular/material';

import { AgreementsService } from '../../services/agreements.service';
import { ProgressBarService, Web3Service } from 'src/app/core/services';
import { SnackbarMessageComponent } from 'src/app/shared/components';

import { takeWhile, switchMap, map } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-agreements-list',
  templateUrl: './agreements-list.component.html',
  styleUrls: ['./agreements-list.component.scss'],
})
export class AgreementsListComponent implements OnInit, OnDestroy {

  @Input()  public  agreements: any;
  @Input()  public  isAdmin: any;
  @Output() public  updateListEvent: EventEmitter<any> = new EventEmitter<any>();

  private _alive: boolean;

  constructor(
    public dialog: MatDialog,
    private _agreementsService:  AgreementsService,
    private _progressBarService: ProgressBarService,
    private _snackBar:           MatSnackBar,
    private _web3Service:        Web3Service
  ) {
    this._alive = true;
  }

  public ngOnInit() {
  }

  public actionsEventHandler(event: any) {
    this._progressBarService.show();
    if (event.action === 'match') {
      this._web3Service.getDaiBalance()
        .pipe(
          switchMap(daiBalance => {
            if (+daiBalance >= +event.agr.nativeData._debtValue) {
              return this._web3Service.allowanceCheck(event.agr.address);
            } else {
              this._snackBar.openFromComponent(SnackbarMessageComponent, { data: { message: 'Insufficient DAI balance', type: 'error' }, duration: 5000 });
              this._progressBarService.hide();
              return of();
            }
          }),
          map(allowance => {
            if (allowance >= event.agr.nativeData._debtValue) {
              this.flexAgreementAction(event);
            } else {
              this.approveTokens(event);
            }
          })
        ).subscribe();
    } else {
      event.selectedAddresses = event.agr ? [event.agr.address] : this.agreements.filter(agr => agr.isSelected).map(agr => agr.address);
      this.flexAgreementAction(event);
    }
  }

  public flexAgreementAction(event: any) {
    this._agreementsService[`${event.action}Agreement`](event)
      .pipe(takeWhile(() => this._alive))
      .subscribe(
        res => this.updateListEvent.next(),
        err => this._progressBarService.hide()
      );
  }

  public approveTokens(data: any) {
    this._agreementsService.spendTokensApprove(data.agr.nativeData._addr, data.agr.nativeData._debtValue)
      .pipe(takeWhile(() => this._alive))
      .subscribe(
        res => this.flexAgreementAction(data),
        err => this._progressBarService.hide()
      );
  }

  public selectedCount(): boolean {
    const numSelected = this.agreements ? this.agreements.filter(agr => agr.status === 'pending' && agr.isSelected).length : 0;
    return numSelected;
  }

  public sortAgreements(event: any) {
    this.agreements = this.agreements.sort((a, b) => {
      const isAsc = event.type === 'asc';
      return this.compare(a[event.fieldName], b[event.fieldName], isAsc);
    });
  }

  public compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  public trackById(index, item) {
    return item.id;
  }

  public ngOnDestroy() {
    this._alive = false;
  }
}
