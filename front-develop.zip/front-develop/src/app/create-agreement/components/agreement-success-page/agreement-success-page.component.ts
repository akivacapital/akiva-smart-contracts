import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-agreement-success-page',
  templateUrl: './agreement-success-page.component.html',
  styleUrls: ['./agreement-success-page.component.scss']
})
export class AgreementSuccessPageComponent implements OnInit {

  public etherscanLink: string;

  constructor(
    private _route: ActivatedRoute,
    private _router: Router
  ) { }

  public ngOnInit() {
    const address = this._route.snapshot.params.address;
    this.etherscanLink = `https://kovan.etherscan.io/tx/${address}`;
  }

  public leavePage() {
    this._router.navigate(['/agreements/all']);
  }
}
