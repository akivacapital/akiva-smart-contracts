import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgreementSuccessPageComponent } from './agreement-success-page.component';

describe('AgreementSuccessPageComponent', () => {
  let component: AgreementSuccessPageComponent;
  let fixture: ComponentFixture<AgreementSuccessPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgreementSuccessPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgreementSuccessPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
