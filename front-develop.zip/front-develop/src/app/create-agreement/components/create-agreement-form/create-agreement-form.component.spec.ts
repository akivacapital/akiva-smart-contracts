import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateAgreementFormComponent } from './create-agreement-form.component';

describe('CreateAgreementFormComponent', () => {
  let component: CreateAgreementFormComponent;
  let fixture: ComponentFixture<CreateAgreementFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateAgreementFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateAgreementFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
