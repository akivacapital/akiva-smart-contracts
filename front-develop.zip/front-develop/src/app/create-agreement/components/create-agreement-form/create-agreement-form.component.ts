import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';

import { COLLATERAL_TYPES } from 'src/assets/mock/mockData';
import { ProgressBarService, MakerDaoService, CheckLoadedService, ConvertDataService } from 'src/app/core/services';
import { CreateAgreementService } from '../../services/create-agreement.service';
import { PatternsConstants } from 'src/app/core/constants';

import { distinctUntilChanged, takeWhile, debounce, finalize, map, switchMap } from 'rxjs/operators';
import { timer } from 'rxjs';

const BigNumber = require('bignumber.js');

@Component({
  selector: 'app-create-agreement-form',
  templateUrl: './create-agreement-form.component.html',
  styleUrls: ['./create-agreement-form.component.scss']
})

export class CreateAgreementFormComponent implements OnInit, OnDestroy {

  public createAgrForm:       FormGroup;
  public amountFormControl:   FormControl;
  public collRateFormControl: FormControl;
  public daiFormControl:      FormControl;
  public expiryFormControl:   FormControl;
  public feeFormControl:      FormControl;
  public mcrFormControl:      FormControl;
  public rateFormControl:     FormControl;
  public typeFormControl:     FormControl;

  public collRate:    number;
  public collTypes:   any;
  public contractABI: any;

  public daiAvailable: any;
  public minDaiAvailable: any;
  public minCollAmount: any;
  public isDisabledButton: boolean;
  public isFormReady: boolean;

  public numberPattern: RegExp = PatternsConstants.NUMBER;

  private _alive: boolean;

  constructor(
    private _checkLoadedService: CheckLoadedService,
    private _convertDataService: ConvertDataService,
    private _createService:      CreateAgreementService,
    private _makerDaoService:    MakerDaoService,
    private _progressBarService: ProgressBarService,
    private _router:             Router,
    private _title:              Title,
  ) {
    this.minDaiAvailable = 25;
    this.collTypes = COLLATERAL_TYPES;
    this._title.setTitle('Create agreement');
    this._alive = true;
  }

  private _createFormControls(): void {
    this.amountFormControl = new FormControl(null);
    this.collRateFormControl = new FormControl(this.collRate);
    this.daiFormControl = new FormControl(null, [
      Validators.required,
      Validators.min(this.minDaiAvailable),
      Validators.pattern(this.numberPattern),
      Validators.max(this.daiAvailable)
    ]);
    this.expiryFormControl = new FormControl(null, [
      Validators.required,
      Validators.min(1), Validators.max(365)
    ]);
    this.feeFormControl  = new FormControl(null);
    this.mcrFormControl  = new FormControl(null);
    this.rateFormControl = new FormControl(null, [
      Validators.required,
      Validators.min(0.1), Validators.max(100)
    ]);
    this.typeFormControl = new FormControl('ETH-A');
  }

  private _createForm(): void {
    this.createAgrForm = new FormGroup({
      amount:       this.amountFormControl,
      collRate:     this.collRateFormControl,
      debt:         this.daiFormControl,
      expiry:       this.expiryFormControl,
      fee:          this.feeFormControl,
      mcr:          this.mcrFormControl,
      interestRate: this.rateFormControl,
      collType:     this.typeFormControl
    });
  }

  public ngOnInit() {
    setTimeout(() => this._progressBarService.show(), 0);

    this._createFormControls();
    this._createForm();

    this._checkLoadedService.checkIsAllLoaded()
      .pipe(takeWhile(() => !this.isFormReady))
      .subscribe(isReady => {
        if (isReady) {
          this.isFormReady = true;
          this.collTypeChange(this.typeFormControl);
          setTimeout(() => this._progressBarService.hide(), 200);
        }
      });

    this.amountFormControl.valueChanges
      .pipe(
        takeWhile(() => this._alive),
        debounce(() => timer(300)),
        distinctUntilChanged()
      )
      .subscribe(amount => this.calcDaiAvailable(amount));

    this.daiFormControl.valueChanges
      .pipe(
        takeWhile(() => this._alive),
        debounce(() => timer(500)),
      )
      .subscribe(() => this.onValuesUpdate());
  }

  public collTypeChange(event: any) {
    this._makerDaoService.cdpType = event.value;
    this._makerDaoService.getMDvalues()
      .pipe(
        map(daoData => {
          this.mcrFormControl.setValue(daoData.mcr);
          this.feeFormControl.setValue(daoData.fee);
          return daoData;
        }),
        switchMap(values => this._makerDaoService.minSafeCollateralAmount(this.minDaiAvailable, values.mcr, values.price)),
        takeWhile(() => this._alive)
      )
      .subscribe(minAmount => {
        this.minCollAmount = minAmount;
        this.amountFormControl.setValidators([Validators.required, Validators.min(minAmount)]);
        this.amountFormControl.updateValueAndValidity();
      });

    if (this.amountFormControl.value) {
      this.calcDaiAvailable(this.amountFormControl.value);
    }
  }

  public createAgreement() {
    if (this.createAgrForm.valid) {

      this._progressBarService.show();
      this.isDisabledButton = true;

      const isErc = this.collTypes.find(t => t.value === this.typeFormControl.value).isErc;
      this.daiFormControl.setValue(this.daiFormControl.value.replace(',', '.'));
      this.createAgrForm.value.expiry =  this.createAgrForm.value.expiry * 24 * 60;

      if (isErc) {
        this._makerDaoService.getERCtoken(this.amountFormControl.value)
        .pipe(takeWhile(() => this._alive))
        .subscribe(
          res => this.createAgreementApprove(isErc),
          err => {
            this._progressBarService.hide();
            this.isDisabledButton = false;
          });
      } else {
        this.createAgreementApprove(isErc);
      }

    } else {
      this.createAgrForm.markAllAsTouched();
    }
  }

  public createAgreementApprove(isErc: boolean) {
    this._createService.createAgreement(this.createAgrForm.value, isErc)
      .pipe(
        takeWhile(() => this._alive),
        finalize(() => {
          this._progressBarService.hide();
          this.isDisabledButton = false;
        })
      )
      .subscribe(res => this._router.navigate([`/create-agreement/success/${res.transactionHash}`]));
  }

  public onValuesUpdate() {

    const daiAvailableBN    = new BigNumber(this.daiAvailable);
    const daiControlValueBN = new BigNumber(this.daiFormControl.value);

    if (daiAvailableBN.gt(this.minDaiAvailable) && daiControlValueBN.gte(daiAvailableBN)) {
      this.daiFormControl.setErrors({ available: true });
      this.daiFormControl.markAsTouched();
    } else {
      this.daiFormControl.updateValueAndValidity();
    }


    if (this.typeFormControl.value && this.amountFormControl.value && this.daiFormControl.value) {
      this._makerDaoService.calcCollRatio(this.amountFormControl.value, this.daiFormControl.value)
        .pipe(takeWhile(() => this._alive))
        .subscribe(cr => this.collRateFormControl.setValue(cr.toFixed(2)));
    }
  }

  public calcDaiAvailable(amount: number) {
    if (amount) {
      amount = this._convertDataService.convertToWei(amount.toString());
      this._makerDaoService.calcDaiAvailable(amount)
        .pipe(takeWhile(() => this._alive))
        .subscribe(available => {
          this.daiAvailable = parseFloat(this._convertDataService.convertFromWei(available.toString())).toFixed(4);
          this.onValuesUpdate();
        });
    }
  }

  public fillInput(type: string) {
    if (type === 'amount') {
      this.amountFormControl.setValue(this.minCollAmount);
    } else {
      this.daiFormControl.setValue(this.daiAvailable);
    }
  }

  public chooseCollSymbol() {
    if (this.typeFormControl.value) {
      return this.collTypes.find(t => t.value === this.typeFormControl.value).symbol;
    }
  }

  public ngOnDestroy() {
    this._alive = false;
  }
}

