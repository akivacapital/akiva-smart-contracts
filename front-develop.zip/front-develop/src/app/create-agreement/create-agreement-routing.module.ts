import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AgreementSuccessPageComponent } from './components/agreement-success-page/agreement-success-page.component';
import { CreateAgreementComponent } from './containers/create-agreement/create-agreement.component';
import { CreateAgreementFormComponent } from './components';

const routes: Routes = [
  {
    path: '',
    component: CreateAgreementComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'new'
      },
      { path: 'new', component: CreateAgreementFormComponent },
      { path: 'success/:address', component: AgreementSuccessPageComponent },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CreateAgreementRoutingModule { }
