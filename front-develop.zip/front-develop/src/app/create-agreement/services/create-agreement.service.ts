import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material';

import { Observable, from } from 'rxjs';
import { Web3Service, ConvertDataService } from 'src/app/core/services';
import { SnackbarMessageComponent } from 'src/app/shared/components';

@Injectable({
  providedIn: 'root'
})
export class CreateAgreementService {

  private _wallet: string;

  constructor(
    private _convertDataService: ConvertDataService,
    private _web3Service:        Web3Service,
    private _snackBar:           MatSnackBar,
  ) { }

  public showError(hash) {
    this._snackBar.openFromComponent(SnackbarMessageComponent, { data: { message: 'Error!', type: 'error', hash }, duration: 7000 });
  }

  public createInstance(type: string, address?: string) {
    this._wallet = this._web3Service.web3Wallet;
    return this._web3Service.getInstance(type, address);
  }

  public createAgreement(form: any, isErc: boolean): Observable<any> {

    // tslint:disable-next-line: prefer-const
    let { amount, debt, expiry, interestRate, collType } = form;

    collType     = this._convertDataService.convertToBytes32(collType);
    amount       = this._convertDataService.convertToWei(this._convertDataService.convertExp(amount));
    debt         = this._convertDataService.convertToWei(this._convertDataService.convertExp(debt));
    interestRate = this._convertDataService.transformSendRate(+interestRate);
    expiry       = expiry * 60;

    if (isErc) {
      return from(
        this.createInstance('factory').methods
          .initAgreementERC20(amount, debt, expiry, interestRate, collType)
          .send({ from: this._wallet })
          .on('error', (error, receipt) => {
            if (receipt) {
              this.showError(receipt.transactionHash);
            }
          }));
    } else {
      return from(
        this.createInstance('factory').methods
          .initAgreementETH(debt, expiry, interestRate, collType)
          .send({ from: this._wallet, value: amount })
          .on('error', (error, receipt) => {
            if (receipt) {
              this.showError(receipt.transactionHash);
            }
          }));
    }

  }
}
