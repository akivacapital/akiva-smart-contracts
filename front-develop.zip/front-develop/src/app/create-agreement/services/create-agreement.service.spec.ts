import { TestBed } from '@angular/core/testing';

import { CreateAgreementService } from './create-agreement.service';

describe('CreateAgreementService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CreateAgreementService = TestBed.get(CreateAgreementService);
    expect(service).toBeTruthy();
  });
});
