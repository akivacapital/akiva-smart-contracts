import { Component } from '@angular/core';

@Component({
  selector: 'app-create-agreement',
  templateUrl: './create-agreement.component.html',
  styleUrls: ['./create-agreement.component.scss']
})
export class CreateAgreementComponent {

  public isWidgetVisible: boolean;

  constructor() { }


  public toogleWidget() {
    this.isWidgetVisible = !this.isWidgetVisible;
  }
}
