import { CommonModule } from '@angular/common';
import { MatInputModule, MatFormFieldModule, MatSelectModule } from '@angular/material';
import { NgModule } from '@angular/core';

import { CreateAgreementRoutingModule } from './create-agreement-routing.module';
import { SharedModule } from '../shared/shared.module';

import { AgreementSuccessPageComponent } from './components/agreement-success-page/agreement-success-page.component';
import { CreateAgreementComponent } from './containers/create-agreement/create-agreement.component';
import { CreateAgreementFormComponent } from './components/create-agreement-form/create-agreement-form.component';
import { CreateAgreementService } from './services/create-agreement.service';

@NgModule({
  declarations: [
    AgreementSuccessPageComponent,
    CreateAgreementComponent,
    CreateAgreementFormComponent,
  ],
  imports: [
    CommonModule,
    CreateAgreementRoutingModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    SharedModule,
  ],
  providers: [ CreateAgreementService ]
})
export class CreateAgreementModule { }
