export class PicturesConstants {
  public static readonly ADD        = '/assets/images/add.svg';
  public static readonly AGREEMENTS = '/assets/images/agreements.svg';
  public static readonly COINBASE   = '/assets/images/coinbase-wallet.svg';
  public static readonly METAMASK   = '/assets/images/metamask-fox.svg';
}
