export class PatternsConstants {
    public static readonly NUMBER: RegExp = /^\d+([,.][0-9]*)?$/;
  }
  