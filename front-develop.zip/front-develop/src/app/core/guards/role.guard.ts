import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { Web3Service } from '../services';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  constructor(
    private _router: Router,
    private _web3Service: Web3Service
  ) { }

  public canActivate(
    route: ActivatedRouteSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    const isAdmin = this._web3Service.isAdmin;

    if (!isAdmin) {
      return true;
    } else {
      this._router.navigate(['/agreements/all']);
      return false;
    }
  }
}
