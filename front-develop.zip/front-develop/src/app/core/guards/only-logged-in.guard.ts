import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Web3Service } from '../services';

@Injectable({
  providedIn: 'root'
})
export class OnlyLoggedInGuard implements CanActivate {

  constructor(
    private _web3Service: Web3Service,
    private _router: Router
  ) { }

  public canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    const isLoggedIn = this._web3Service.web3Provider;
    if (isLoggedIn) {
      return true;
    } else {
      console.warn(`This page only for Unauthorized users.`, `Warning!`);
      this._router.navigate(['/authorization/log-in']);
      return false;
    }

  }
}
