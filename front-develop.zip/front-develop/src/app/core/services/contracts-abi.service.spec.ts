import { TestBed } from '@angular/core/testing';

import { ContractsAbiService } from './contracts-abi.service';

describe('ContractsAbiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ContractsAbiService = TestBed.get(ContractsAbiService);
    expect(service).toBeTruthy();
  });
});
