import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material';

import { SnackbarMessageComponent } from 'src/app/shared/components/snackbar-message/snackbar-message.component';

import { ContractsAbiService } from './contracts-abi.service';
import { SessionStorageService } from './session-storage.service';

import { WalletData } from '../interfaces/walletData.interface';

import { Subject, Observable, from } from 'rxjs';

import WalletLink from 'walletlink';
import { environment } from 'src/environments/environment';

// tslint:disable-next-line: variable-name
const Web3 = require('web3');

export const walletLink = new WalletLink({
  appName: environment.APP_NAME,
});

@Injectable({
  providedIn: 'root'
})
export class Web3Service {

  private _walletSubject = new Subject<WalletData>();

  public walletSubject$ = this._walletSubject.asObservable();

  private _web3: any;
  private _wallet: string;
  private _isAdmin: boolean;

  constructor(
    private _contractAbiService: ContractsAbiService,
    private _snackBar: MatSnackBar,
    private _sessionStorageService: SessionStorageService
  ) { }

  public get web3Provider() {
    return this._web3;
  }

  public set web3Wallet(wallet: string) {
    this._wallet = wallet;
  }

  public get web3Wallet() {
    return this._wallet;
  }

  public get isAdmin() {
    return this._isAdmin;
  }

  public getWallets(): Observable<any> {
    return from(this._web3.eth.getAccounts());
  }

  public createProvider(walletType: string): void {
    let provider: any;

    this._web3 = null;

    switch (walletType) {
      case 'coinbase':
        provider = walletLink.makeWeb3Provider(environment.WALLETLINK_NET, environment.CHAIN_ID);
        provider.on('accountsChanged', (accounts: string[]) => {
          if (accounts && accounts[0] && accounts[0] !== this._wallet) {
            this._wallet = accounts[0];
            this.updateWalletSubject(walletType);
          }
        });
        break;
      case 'metamask':
        provider = ('ethereum' in window) ? window['ethereum'] : Web3.givenProvider;
        provider.publicConfigStore
          .on('update', wallet => {
            if (wallet && wallet.selectedAddress && wallet.selectedAddress !== this._wallet) {
              this._wallet = wallet.selectedAddress;
              this.updateWalletSubject(walletType);
            }
          });
        break;
    }

    if (provider) {
      this._web3 = new Web3(provider as any);
    } else {
      this._snackBar.openFromComponent(SnackbarMessageComponent, {
        data: { message: `Non-Ethereum browser detected. You should consider trying ${walletType}`, type: 'error' },
        duration: 7000
      });
    }

  }

  public async enableProvider() {
    if ('enable' in this._web3.currentProvider) {
      await this._web3.currentProvider.enable();
    }
  }

  public updateWalletSubject(type: string) {
    this._sessionStorageService.set('wallet', { type, address: this._wallet });

    const instance = this.getInstance('factory');

    (instance.methods.isAdmin(this._wallet).call())
      .then((isAdmin: boolean) => {
        this._isAdmin = isAdmin;
        this._walletSubject.next({ address: this._wallet, type, isAdmin});
      });
  }

  public getInstance(instType: string, aggAddress?: string) {
    let abi, address: string;
    switch (instType) {
      case 'factory':
        abi = this._contractAbiService.fraFactoryABI;
        address = environment.FRA_FACTORY_ADDRESS;
        break;
      case 'queries':
        abi = this._contractAbiService.queriesABI;
        address = environment.FRA_QUERIES_ADDRESS;
        break;
      case 'agreement':
        abi = this._contractAbiService.agreementABI;
        address = aggAddress;
        break;
      case 'dai':
        abi = this._contractAbiService.daiABI;
        address = aggAddress || environment.DAI_ADDRESS;
        break;
    }
    return new this._web3.eth.Contract(abi, address);
  }

  public getBalance(): Observable<any> {
    return from(this._web3.eth.getBalance(this._wallet));
  }

  public getDaiBalance(): Observable<any> {
    return from(this.getInstance('dai').methods.balanceOf(this._wallet).call());
  }

  public getAgreementsCounts(): Observable<any> {
    return from(this.getInstance('queries').methods.getAgreementsCount(environment.FRA_FACTORY_ADDRESS).call());
  }

  public getTotalCdps(): Observable<any> {
    return from(this.getInstance('queries').methods.getTotalCdps(environment.FRA_FACTORY_ADDRESS).call());
  }

  public getActiveCdps(): Observable<any> {
    return from(this.getInstance('queries').methods.getActiveCdps(environment.FRA_FACTORY_ADDRESS).call());
  }

  public allowanceCheck(address: string): Observable<any> {
    return from(this.getInstance('dai').methods.allowance(this._wallet, address).call());
  }

  public getBlockTime(block): Observable<any> {
    return from(this._web3.eth.getBlock(block));
  }
}
