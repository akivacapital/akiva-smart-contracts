import { TestBed } from '@angular/core/testing';

import { CheckLoadedService } from './check-loaded.service';

describe('CheckLoadedService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CheckLoadedService = TestBed.get(CheckLoadedService);
    expect(service).toBeTruthy();
  });
});
