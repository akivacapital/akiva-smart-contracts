import { Injectable } from '@angular/core';
import { Web3Service } from './web3.service';
import { AGREEMENT_STATUSES } from 'src/assets/mock/mockData';

import fromExponential from 'from-exponential';

@Injectable({
  providedIn: 'root'
})
export class ConvertDataService {

  public RAY: number = 1e27;

  constructor(
    private _web3Service: Web3Service
  ) { }

  public transmormAgreementsData(agreements: any) {

    const updatedAgreements = [];

    agreements.forEach(agr => {

      const item = {
        address:          agr._addr,
        borrower:         agr._borrower,
        collateralAmount: this.convertFromWei(agr._collateralAmount),
        collateralType:   this.convertFromBytes32(agr._collateralType),
        debtValue:        this.convertFromWei(agr._debtValue),
        duration:         parseFloat((agr._duration / (24 * 60 * 60)).toFixed(2)),
        interestRate:     this.transformRecievedRate(agr._interestRate),
        lender:           !agr._lender.match(/0x00000/g) ? agr._lender : '',
        nativeData:       agr,
        role:             this.checkAgreementRole(agr._borrower, agr._lender),
        status:           this.checkStatus(agr._status, +agr._closedType),
        closedType:       +agr._closedType,
        isRisky:          agr._isRisky
      };

      updatedAgreements.push(item);
    });

    return updatedAgreements;
  }

  public checkStatus(statusId: string, closedType: number) {

    let status = AGREEMENT_STATUSES.filter(s => s.id === statusId)[0].status;

    if (status === 'closed') {
      switch (closedType) {
        case (0):
          status = 'ended';
          break;
        case (1):
          status = 'liquidated';
          break;
        case (2):
          status = 'blocked';
          break;
        case (3):
          status = 'canceled';
          break;
        default:
          break;
      }
    }

    return status;
  }

  public convertExp(amount: any) {
    return fromExponential(amount);
  }

  public convertToWei(amount: string) {
    return this._web3Service.web3Provider.utils.toWei(amount, 'ether');
  }

  public convertFromWei(amount: any, isRad?: boolean) {
    const result = this._web3Service.web3Provider.utils.fromWei(amount, 'ether');
    return isRad ? fromExponential((result / this.RAY).toFixed(18)) : result;
  }

  public convertToBytes32(collateralType: string) {
    return this._web3Service.web3Provider.utils.padRight(this._web3Service.web3Provider.utils.fromAscii(collateralType), 64);
  }

  public convertFromBytes32(collateralType: string) {
    return this._web3Service.web3Provider.utils.hexToUtf8(collateralType);
  }

  public transformRecievedRate(rate: number): number {
    return parseFloat((rate / this.RAY * 100 - 100).toFixed(2));
  }

  public transformSendRate(rate: number): any {
    return fromExponential(rate * this.RAY / 100 + this.RAY);
  }

  public checkAgreementRole(borrower: string, lender: string) {

    const currentWallet = this._web3Service.web3Wallet;

    switch (currentWallet.toLowerCase()) {
      case borrower.toLowerCase():
        return 'borrower';
      case lender.toLowerCase():
        return 'lender';
      default:
        return 'customer';
    }
  }
}
