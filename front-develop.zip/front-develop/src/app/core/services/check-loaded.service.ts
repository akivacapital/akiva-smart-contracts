import { Injectable } from '@angular/core';
import { interval } from 'rxjs';
import { map } from 'rxjs/operators';

import { ContractsAbiService } from './contracts-abi.service';
import { MakerDaoService } from './maker-dao.service';
import { Web3Service } from './web3.service';

@Injectable({
  providedIn: 'root'
})
export class CheckLoadedService {

  constructor(
    private _abiService:  ContractsAbiService,
    private _mdService:   MakerDaoService,
    private _web3Service: Web3Service,
  ) { }

  public checkIsAllLoaded() {
    return interval(200).pipe(
      map(() => (this._web3Service.web3Provider && this._mdService.cdpType && this._abiService.isABILoaded))
    );
  }
}
