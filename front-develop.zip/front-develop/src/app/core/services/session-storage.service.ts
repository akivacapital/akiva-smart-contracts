import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SessionStorageService {

  public sessionStorage: any = sessionStorage;
  private _prefix: string = environment.APP_NAME;

  constructor() {
    if (!sessionStorage) {
      throw new Error('Current browser does not support Session Storage');
    }
  }

  public set(key: string, value: any): void {
    const checkedValue = (typeof value === 'object') ? JSON.stringify(value) : value;
    this.sessionStorage.setItem(`${this._prefix}_${key}`, checkedValue);
  }

  public get(key: string): any {
    return JSON.parse(this.sessionStorage.getItem([`${this._prefix}_${key}`] || false));
  }

  public remove(key: string): void {
    this.sessionStorage.removeItem(`${this._prefix}_${key}`);
  }

  public clear(): void {
    this.sessionStorage.clear();
  }

}
