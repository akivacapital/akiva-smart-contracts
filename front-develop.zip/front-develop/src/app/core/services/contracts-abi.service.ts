import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContractsAbiService {

  private _agreementABI:  any;
  private _configABI:     any;
  private _daiABI:        any;
  private _fraFactoryABI: any;
  private _fraQueriesABI: any;

  private _abiLoaded: boolean;

  constructor(
    private _http: HttpClient
  ) { }

  public initializeABI(): Observable<any> {

    const sources: any = [
      this._http.get(`./assets/contracts/FraFactory.json`),
      this._http.get(`./assets/contracts/Agreement.json`),
      this._http.get(`./assets/contracts/IERC20.json`),
      this._http.get(`./assets/contracts/FraQueries.json`),
      // this._http.get(`./assets/contracts/Config.json`)
    ];

    return sources;
  }

  public get fraFactoryABI() {
    return this._fraFactoryABI;
  }

  public get agreementABI() {
    return this._agreementABI;
  }

  public get daiABI() {
    return this._daiABI;
  }

  // public get configABI() {
  //   return this._configABI;
  // }

  public get queriesABI() {
    return this._fraQueriesABI;
  }

  public get isABILoaded() {
    return this._abiLoaded;
  }

  public set setABIs(abis: any) {
    this._fraFactoryABI = abis[0].abi;
    this._agreementABI  = abis[1].abi;
    this._daiABI        = abis[2].abi;
    this._fraQueriesABI = abis[3].abi;
    // this._configABI     = abis[4].abi;

    this._abiLoaded = true;
  }
}
