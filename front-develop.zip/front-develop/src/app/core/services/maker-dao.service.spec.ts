import { TestBed } from '@angular/core/testing';

import { MakerDaoService } from './maker-dao.service';

describe('MakerDaoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MakerDaoService = TestBed.get(MakerDaoService);
    expect(service).toBeTruthy();
  });
});
