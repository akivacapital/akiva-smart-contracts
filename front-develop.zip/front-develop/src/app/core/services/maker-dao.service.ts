import { Injectable } from '@angular/core';

import Maker from '@makerdao/dai';
import McdPlugin, { ETH, MDAI, REP, ZRX, OMG, BAT, DGD, GNT } from '@makerdao/dai-plugin-mcd';

import { Observable, of, from, throwError, empty, scheduled } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MakerDaoService {

  private _cdpType: any;
  private _cdpTypeService: any;
  private _savingsService: any;
  private _managerService: any;

  constructor() { }

  public createMDProvider() {
    (Maker.create('browser', { plugins: [[McdPlugin]] })).then(maker => {
      this._cdpTypeService = maker.service('mcd:cdpType');
      this._savingsService = maker.service('mcd:savings');
      this._managerService = maker.service('mcd:cdpManager');
      this._cdpType  = this._cdpTypeService.getCdpType(null, 'ETH-A');
    });
  }

  public resetCdp(): Observable<any> {
    return from(this._cdpType.reset().then(() => this._cdpType.prefetch()));
  }

  public set cdpType(type: string) {
    this._cdpType = this._cdpTypeService.getCdpType(null, type);
  }

  public get cdpType() {
    return this._cdpType;
  }

  public getERCtoken(debt: any, agrAddress?: string): Observable<any> {
    return from((Maker.create('browser', { plugins: [[McdPlugin]] })).then(maker => {
      return maker.getToken(this._cdpType.currency).approve(agrAddress || environment.FRA_FACTORY_ADDRESS, debt);
    })).pipe(catchError(error => throwError(error)));
  }

  public getMDvalues(): Observable<any> {
    const price = this._cdpType.price.toNumber();
    const mcr   = (this._cdpType.liquidationRatio.toNumber() * 100);
    const fee   = (this._cdpType.annualStabilityFee * 100).toFixed(1);
    return of({ price, mcr, fee});
  }

  public getDSR(): Observable<any> {
    return from(this._savingsService.getYearlyRate());
  }

  public calcCollRatio(collAmount, debt): Observable<any> {
    const value = ((collAmount * this._cdpType.price.toNumber()) / debt) * 100;
    return of((isNaN(value) ? 0 : value));
  }

  public calcDaiAvailable(collAmount): Observable<any> {
    const value = collAmount * this._cdpType.price.toNumber() / this._cdpType.liquidationRatio.toNumber();
    return of(isNaN(value) ? 0 : value);
  }

  public minSafeCollateralAmount(debtValue, liquidationRatio, price): Observable<any> {
    return of(debtValue * (liquidationRatio / 100) / price);
  }

  public getDetailsAdditionalInfo(cdpId: number): Observable<any> {
    return from(
        (this._managerService.getCdp(cdpId)).then(data => {
          return {
            collRatio: data.collateralizationRatio.toNumber().toFixed(2) * 100,
            debtValue: data.debtValue.toNumber(),
            collValue: data.collateralValue.toNumber(),
            collAmount: data.collateralAmount.toNumber()
          };
        })
    );
  }

  public getCombinedColValue(ids: []): Observable<any> {
    const values: any = [];

    ids.forEach(id => values.push(this._managerService.getCdp(+id).then(cdp => cdp.collateralValue)));
    return ids.length ? values : of([{}]);
  }
}
