import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProgressBarService {

  public isShown: boolean;
  public value: number;

  public mode:  'determinate' | 'indeterminate' | 'buffer' | 'query' = 'indeterminate';
  public color: 'primary' | 'accent' | 'warn' = 'primary';

  private _progressBarAnnouncedSource = new Subject<IProgressBar>();

  constructor() { }

  public progressBarAnnounced$ = this._progressBarAnnouncedSource.asObservable();

  public show(data?: IProgressBar): void {

    if (!data) {
      data = {};
    }

    data.mode  = data.mode || 'indeterminate';
    data.color = data.color || this.color;
    data.isShown = true;

    if (data.value >= 100) {
      this.show();
    } else {
      this._progressBarAnnouncedSource.next(data);
    }

    setTimeout(() => this.hide(), 180000);
  }

  public hide(): void {
    this._progressBarAnnouncedSource.next({ isShown: false });
  }

}

export interface IProgressBar {
  isShown?: boolean;
  value?:   number;
  mode?:    'determinate' | 'indeterminate' | 'buffer' | 'query';
  color?:   'primary' | 'accent' | 'warn';
}
