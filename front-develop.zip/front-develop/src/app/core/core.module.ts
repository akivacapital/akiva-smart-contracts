import { NgModule, Optional, SkipSelf } from '@angular/core';
import { MatProgressBarModule, MatSnackBarModule } from '@angular/material';

import { throwIfAlreadyLoaded } from './utils';

@NgModule({
  declarations: [],
  imports: [
    MatProgressBarModule,
    MatSnackBarModule
  ],
  exports: [
    MatProgressBarModule
  ]
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    throwIfAlreadyLoaded(parentModule, 'CoreModule');
  }
}
