export * from './walletData.interface';
