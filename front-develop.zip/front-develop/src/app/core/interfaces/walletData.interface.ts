export interface WalletData {
  address: string;
  type:    string;
  isAdmin: boolean;
}
