import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { SharedModule } from '../shared/shared.module';
import { UserItemComponent } from './components/user-item/user-item.component';
import { UsersComponent } from './containers';
import { UsersListComponent } from './components/users-list/users-list.component';
import { UsersRoutingModule } from './users-routing.module';
import { UsersHeaderComponent } from './components/users-header/users-header.component';

@NgModule({
  declarations: [
    UserItemComponent,
    UsersComponent,
    UsersListComponent,
    UsersHeaderComponent,
  ],
  imports: [
    CommonModule,
    UsersRoutingModule,
    SharedModule,
  ]
})
export class UsersModule { }
