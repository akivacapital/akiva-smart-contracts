import { Injectable } from '@angular/core';

import { Web3Service } from 'src/app/core/services';
import { environment } from 'src/environments/environment';

import { Observable, from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(
    private _web3Service: Web3Service
  ) { }

  public createInstance(type: string, address?: string) {
    return this._web3Service.getInstance(type, address);
  }

  public getUsers(): Observable<any> {
    return from(this.createInstance('queries').methods.getUsers(environment.FRA_FACTORY_ADDRESS).call());
  }
}
