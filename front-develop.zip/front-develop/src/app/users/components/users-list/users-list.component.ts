import { Component, OnInit, OnDestroy } from '@angular/core';

import { CheckLoadedService } from 'src/app/core/services';
import { UsersService } from '../../services/users.service';

import { takeWhile } from 'rxjs/operators';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss']
})
export class UsersListComponent implements OnInit, OnDestroy {

  public isLoaded: boolean;
  public usersAddress: any;

  private _alive: boolean;

  constructor(
    private _checkLoadedService: CheckLoadedService,
    private _usersService:       UsersService,
  ) {
    this._alive = true;
  }

  public ngOnInit() {
    this._checkLoadedService.checkIsAllLoaded()
      .pipe(takeWhile(() => !this.isLoaded))
      .subscribe(isReady => {
        if (isReady && !this.isLoaded) {
          this.getUsers();
        }
      });
  }

  public getUsers() {

    this.isLoaded = true;

    this._usersService.getUsers()
    .pipe(takeWhile(() => this._alive))
    .subscribe(res => {
      const addresses = [...res.borrowers, ...res.lenders].filter(a => !a.match(/0x00000/g));
      this.usersAddress = new Set(addresses);
    });
  }

  public ngOnDestroy() {
    this._alive = false;
  }
}
