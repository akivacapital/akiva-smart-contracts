import { Component, OnInit, Input } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { SnackbarMessageComponent } from 'src/app/shared/components';

@Component({
  selector: 'app-user-item',
  templateUrl: './user-item.component.html',
  styleUrls: ['./user-item.component.scss']
})
export class UserItemComponent implements OnInit {

  @Input() public user: any;
  @Input() public index: any;

  constructor(
    private _snackBar: MatSnackBar,
  ) { }

  ngOnInit() {
  }

  public copyToClipboard(item) {
    document.addEventListener('copy', (e: ClipboardEvent) => {
      e.clipboardData.setData('text/plain', (item));
      e.preventDefault();
      document.removeEventListener('copy', null);
    });
    document.execCommand('copy');
    this._snackBar.openFromComponent(SnackbarMessageComponent, { data: { message: 'Copied to clipboard', type: 'success' }, duration: 1250 });
  }
}
